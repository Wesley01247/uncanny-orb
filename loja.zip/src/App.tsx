import React, { useState, useEffect } from 'react';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_ASSISTANCE_RECORDS, 
  INITIAL_WARRANTIES 
} from './data/mockData';
import { 
  Product, 
  CartItem, 
  Order, 
  TechnicalAssistanceOS, 
  Warranty, 
  Coupon, 
  OSStatus, 
  DeliveryStatus 
} from './types';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { TechnicalAssistance } from './components/TechnicalAssistance';
import { WarrantyConsultation } from './components/WarrantyConsultation';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AdminPanel } from './components/AdminPanel';
import { SupportChatModal } from './components/SupportChatModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { SlidersHorizontal, ArrowUpDown } from 'lucide-react';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState(true);

  // App Navigation
  const [activeTab, setActiveTab] = useState<'catalogo' | 'assistencia' | 'garantias' | 'pedidos' | 'admin'>('catalogo');
  
  // Data State
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'PED-2026-9140',
      customerName: 'Renato Silveira Bueno',
      customerPhone: '(67) 99876-1122',
      customerEmail: 'renato.bueno@gmail.com',
      customerCpf: '340.***.***-20',
      deliveryType: 'retirada',
      shippingFee: 0,
      items: [
        {
          productId: 'prod-1',
          name: 'iPhone 13 Apple 128GB - Meia-Noite (Seminovo)',
          price: 3599.00,
          quantity: 1,
          color: 'Meia-Noite',
          storage: '128GB',
          image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80'
        }
      ],
      subtotal: 3599.00,
      discount: 0,
      total: 3599.00,
      paymentMethod: 'pix',
      paymentStatus: 'pago',
      deliveryStatus: 'pronto_retirada',
      createdAt: new Date(Date.now() - 3600000 * 3).toISOString()
    }
  ]);
  const [osList, setOsList] = useState<TechnicalAssistanceOS[]>(INITIAL_ASSISTANCE_RECORDS);
  const [warranties, setWarranties] = useState<Warranty[]>(INITIAL_WARRANTIES);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [shippingFee, setShippingFee] = useState(0);
  const [deliveryType, setDeliveryType] = useState<'retirada'>('retirada');
  const [isChatOpen, setIsChatOpen] = useState(false);

  // Search & Filtering
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedCondition, setSelectedCondition] = useState<'todos' | 'seminovo' | 'novo'>('todos');
  const [selectedBrand, setSelectedBrand] = useState('Todos');
  const [sortBy, setSortBy] = useState<'destaques' | 'menor_preco' | 'maior_preco'>('destaques');

  // Toggle Theme effect on root
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('theme-light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('theme-light');
    }
  }, [isDark]);

  // Cart Handlers
  const handleAddToCart = (product: Product, quantity = 1, color?: string, storage?: string) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(
        item => item.product.id === product.id &&
                item.selectedColor === color &&
                item.selectedStorage === storage
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      }

      return [...prev, { product, quantity, selectedColor: color, selectedStorage: storage }];
    });
    setIsCartOpen(true);
  };

  const handleBuyNow = (product: Product, quantity = 1, color?: string, storage?: string) => {
    handleAddToCart(product, quantity, color, storage);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleUpdateQuantity = (index: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCart(prev => {
      const updated = [...prev];
      updated[index].quantity = quantity;
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleProceedToCheckout = (coupon: Coupon | null, fee: number, type: 'retirada') => {
    setAppliedCoupon(coupon);
    setShippingFee(fee);
    setDeliveryType('retirada');
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderPlaced = (order: Order) => {
    setOrders(prev => [order, ...prev]);
    // Deduct stock for products
    order.items.forEach(item => {
      setProducts(prev => prev.map(p => {
        if (p.id === item.productId) {
          return { ...p, stock: Math.max(0, p.stock - item.quantity) };
        }
        return p;
      }));
    });
    setCart([]);
  };

  // OS Handlers
  const handleCreateOS = (newOS: TechnicalAssistanceOS) => {
    setOsList(prev => [newOS, ...prev]);
  };

  const handleUpdateOSStatus = (protocol: string, status: OSStatus, approved?: boolean) => {
    setOsList(prev => prev.map(os => {
      if (os.protocol === protocol) {
        return {
          ...os,
          status,
          customerApproved: approved !== undefined ? approved : os.customerApproved,
          updatedAt: new Date().toISOString()
        };
      }
      return os;
    }));
  };

  const handleAdminUpdateOS = (protocol: string, status: OSStatus, partsCost: number, laborCost: number, notes: string) => {
    setOsList(prev => prev.map(os => {
      if (os.protocol === protocol) {
        return {
          ...os,
          status,
          partsCost,
          laborCost,
          totalCost: partsCost + laborCost,
          technicianNotes: notes,
          updatedAt: new Date().toISOString()
        };
      }
      return os;
    }));
  };

  // Admin Handlers
  const handleUpdateOrderStatus = (orderId: string, deliveryStatus: DeliveryStatus, paymentStatus?: any) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          deliveryStatus,
          paymentStatus: paymentStatus || (deliveryStatus === 'pago' ? 'pago' : o.paymentStatus)
        };
      }
      return o;
    }));
  };

  const handleAddProduct = (newProd: Product) => {
    setProducts(prev => [newProd, ...prev]);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const handleUpdateStock = (productId: string, newStock: number) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: newStock } : p));
  };

  const handleAddWarranty = (newWar: Warranty) => {
    setWarranties(prev => [newWar, ...prev]);
  };

  // Filtered Products
  const filteredProducts = products.filter(p => {
    const matchesSearch = searchQuery === '' || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'Todos' || p.category === selectedCategory;
    const matchesCondition = selectedCondition === 'todos' || p.condition === selectedCondition;
    const matchesBrand = selectedBrand === 'Todos' || p.brand === selectedBrand;

    return matchesSearch && matchesCategory && matchesCondition && matchesBrand;
  }).sort((a, b) => {
    const priceA = a.promotionalPrice || a.price;
    const priceB = b.promotionalPrice || b.price;

    if (sortBy === 'menor_preco') return priceA - priceB;
    if (sortBy === 'maior_preco') return priceB - priceA;
    return (b.bestseller ? 1 : 0) - (a.bestseller ? 1 : 0);
  });

  const cartItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-[#080d19] text-white' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab: any) => setActiveTab(tab)}
        cartCount={cartItemsCount}
        openCart={() => setIsCartOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        isDark={isDark}
        toggleTheme={() => setIsDark(!isDark)}
        openChat={() => setIsChatOpen(true)}
      />

      {/* Main Content Area based on Active Tab */}
      <main className="flex-1">
        
        {/* TAB 1: CATALOGO */}
        {activeTab === 'catalogo' && (
          <div>
            {/* Hero Banner */}
            <HeroBanner
              onGoToAssistance={() => setActiveTab('assistencia')}
              onGoToCatalog={() => {
                const el = document.getElementById('vitrine-produtos');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Vitrine de Produtos */}
            <div id="vitrine-produtos" className="max-w-7xl mx-auto px-4 py-10">
              
              {/* Filter and Sorting Controls */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8 bg-[#121826] p-4 sm:p-5 rounded-2xl border border-white/10 shadow-lg">
                
                {/* Condition Pills */}
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="text-slate-400 font-semibold flex items-center gap-1">
                    <SlidersHorizontal className="w-3.5 h-3.5" /> Condição:
                  </span>
                  <button
                    onClick={() => setSelectedCondition('todos')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      selectedCondition === 'todos'
                        ? 'bg-[#1fa64b] text-white'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    Todos ({products.length})
                  </button>

                  <button
                    onClick={() => setSelectedCondition('seminovo')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      selectedCondition === 'seminovo'
                        ? 'bg-[#f4c430] text-[#0b2c5a]'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    Seminovos (Garantia 90 Dias)
                  </button>

                  <button
                    onClick={() => setSelectedCondition('novo')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      selectedCondition === 'novo'
                        ? 'bg-[#1fa64b] text-white'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    Acessórios Originais (90 Dias)
                  </button>
                </div>

                {/* Brand & Sort by */}
                <div className="flex flex-wrap items-center gap-3 text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-400 font-medium">Marca:</span>
                    <select
                      value={selectedBrand}
                      onChange={(e) => setSelectedBrand(e.target.value)}
                      className="bg-slate-900 text-white border border-white/20 rounded-lg px-2.5 py-1.5 outline-none focus:border-[#1fa64b]"
                    >
                      <option value="Todos">Todas as marcas</option>
                      <option value="Apple">Apple iPhone</option>
                      <option value="Samsung">Samsung Galaxy</option>
                      <option value="Xiaomi">Xiaomi / Poco</option>
                      <option value="Motorola">Motorola</option>
                      <option value="JBL">JBL</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                    <select
                      value={sortBy}
                      onChange={(e: any) => setSortBy(e.target.value)}
                      className="bg-slate-900 text-white border border-white/20 rounded-lg px-2.5 py-1.5 outline-none focus:border-[#1fa64b]"
                    >
                      <option value="destaques">Mais Vendidos / Destaques</option>
                      <option value="menor_preco">Menor Preço</option>
                      <option value="maior_preco">Maior Preço</option>
                    </select>
                  </div>
                </div>

              </div>

              {/* Products Grid using Card Structure */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-items-center">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                      onViewProduct={(p) => setSelectedProduct(p)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-[#121826] rounded-3xl border border-white/10 p-8">
                  <p className="text-base font-bold text-white mb-1">Nenhum produto encontrado</p>
                  <p className="text-xs text-slate-400">
                    Tente ajustar os filtros de categoria ou termo de busca.
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('Todos');
                      setSelectedCondition('todos');
                      setSelectedBrand('Todos');
                    }}
                    className="mt-4 px-4 py-2 rounded-xl bg-[#1fa64b] text-white text-xs font-bold cursor-pointer"
                  >
                    Limpar Filtros
                  </button>
                </div>
              )}

            </div>
          </div>
        )}

        {/* TAB 2: ASSISTÊNCIA TÉCNICA (OS) */}
        {activeTab === 'assistencia' && (
          <TechnicalAssistance
            osList={osList}
            onCreateOS={handleCreateOS}
            onUpdateOSStatus={handleUpdateOSStatus}
          />
        )}

        {/* TAB 3: GARANTIAS & IMEI */}
        {activeTab === 'garantias' && (
          <WarrantyConsultation
            warranties={warranties}
          />
        )}

        {/* TAB 4: ACOMPANHAR PEDIDO */}
        {activeTab === 'pedidos' && (
          <OrderTrackingModal
            orders={orders}
          />
        )}

        {/* TAB 5: ADMIN PANEL */}
        {activeTab === 'admin' && (
          <AdminPanel
            products={products}
            orders={orders}
            osList={osList}
            warranties={warranties}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpdateOS={handleAdminUpdateOS}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
            onUpdateStock={handleUpdateStock}
            onAddWarranty={handleAddWarranty}
            onBackToStore={() => setActiveTab('catalogo')}
          />
        )}

      </main>

      {/* Product Detail Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onDeleteProduct={(id) => {
          handleDeleteProduct(id);
          setSelectedProduct(null);
        }}
      />

      {/* Cart Slide-Over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={handleProceedToCheckout}
      />

      {/* Checkout Modal with PagBank Pix */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        coupon={appliedCoupon}
        shippingFee={shippingFee}
        deliveryType={deliveryType}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* Support Chat with Gemini AI */}
      <SupportChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />

      {/* Floating WhatsApp Button */}
      <FloatingWhatsApp />

      {/* Footer */}
      <Footer
        onNavigate={(tab: any) => setActiveTab(tab)}
      />

    </div>
  );
}
