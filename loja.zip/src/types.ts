export type ConditionType = 'novo' | 'seminovo';

export interface Product {
  id: string;
  name: string;
  category: 'Smartphones' | 'Tablets' | 'Acessórios' | 'Baterias' | 'Carregadores & Cabos' | 'Caixas de Som' | 'Peças & Telas';
  brand: 'Apple' | 'Samsung' | 'Xiaomi' | 'Motorola' | 'Realme' | 'JBL' | 'Outros';
  condition: ConditionType;
  description: string;
  specs: {
    tela?: string;
    armazenamento?: string;
    ram?: string;
    bateria?: string;
    camera?: string;
    processador?: string;
    conexao?: string;
    garantia?: string;
  };
  options?: {
    cores?: string[];
    armazenamento?: string[];
  };
  price: number;
  promotionalPrice?: number;
  stock: number;
  costPrice: number; // Para gestão financeira interna
  images: string[];
  bestseller?: boolean;
  featured?: boolean;
  warrantyMonths: number;
  rating: number;
  reviewsCount: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedStorage?: string;
}

export type PaymentMethod = 'pix' | 'cartao' | 'dinheiro_retirada';
export type PaymentStatus = 'aguardando' | 'pago' | 'cancelado';
export type DeliveryStatus = 
  | 'aguardando_pagamento'
  | 'pago'
  | 'em_separacao'
  | 'pronto_retirada'
  | 'retirado'
  | 'cancelado'
  | 'em_preparacao'
  | 'saiu_para_entrega'
  | 'entregue';

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  customerCpf: string;
  deliveryType: 'retirada';
  deliveryAddress?: {
    rua: string;
    numero: string;
    bairro: string;
    cidade: string;
    cep?: string;
    complemento?: string;
    pontoReferencia?: string;
  };
  shippingFee: number;
  items: {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    color?: string;
    storage?: string;
    image: string;
  }[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  deliveryStatus: DeliveryStatus;
  pagbankChargeId?: string;
  pixQrCode?: string;
  pixCopiaECola?: string;
  pixExpiresAt?: string;
  createdAt: string;
  courierName?: string;
  trackingNotes?: string;
}

export type OSStatus = 
  | 'recebido'
  | 'analise_tecnica'
  | 'orcamento_pronto'
  | 'aguardando_aprovacao'
  | 'aprovado'
  | 'em_reparo'
  | 'testes_finais'
  | 'pronto_retirada'
  | 'entregue'
  | 'recusado';

export interface TechnicalAssistanceOS {
  id: string;
  protocol: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  deviceType: 'Celular' | 'Tablet' | 'Outro';
  brand: string;
  model: string;
  defectDescription: string;
  photoUrl?: string;
  status: OSStatus;
  partsCost: number;
  laborCost: number;
  totalCost: number;
  technicianNotes?: string;
  customerApproved?: boolean | null;
  createdAt: string;
  updatedAt: string;
}

export interface Warranty {
  id: string;
  protocol: string;
  imeiOrSerial: string;
  productName: string;
  customerName: string;
  customerPhone: string;
  customerCpf?: string;
  purchaseDate: string;
  expirationDate: string;
  warrantyMonths: number;
  condition: ConditionType;
  status: 'ativa' | 'expirada' | 'em_atendimento';
  terms: string;
}

export interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minPurchase: number;
  active: boolean;
}

export interface FinancialMetric {
  totalRevenue: number;
  totalCost: number;
  grossProfit: number;
  marginPercent: number;
  totalOrders: number;
  paidOrdersCount: number;
  activeOSCount: number;
  lowStockItemsCount: number;
}
