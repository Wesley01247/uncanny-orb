import { Product, TechnicalAssistanceOS, Warranty, Coupon } from '../types';

export const STORE_INFO = {
  name: 'Digital Cell Celulares',
  city: 'Itaquiraí',
  state: 'MS',
  phone: '67981359433',
  phoneFormatted: '(67) 9 8135-9433',
  whatsappUrl: 'https://wa.me/5567981359433',
  address: 'Rua Campo Grande, 1161 - Centro, Itaquiraí - MS',
  hours: 'Segunda a Sexta: 08:00 às 11:30 e das 13:00 às 18:00 | Sábado: 08:00 às 12:00 | Domingo: Fechado',
  logoUrl: '/assets/aistudio/IMG-20261030-WA0000_83967ecf.jpg',
  colors: {
    primary: '#0b2c5a', // Azul-marinho
    green: '#1fa64b',   // Verde oficial
    yellow: '#f4c430',  // Amarelo
    white: '#ffffff',
    dark: '#121826',
    darkSecondary: '#1a1a1a'
  }
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'iPhone 13 Apple 128GB - Meia-Noite (Seminovo)',
    category: 'Smartphones',
    brand: 'Apple',
    condition: 'seminovo',
    description: 'Aparelho seminovo impecável, 100% revisado pela equipe técnica da Digital Cell. Saúde da bateria excelente (>86%), tela Super Retina XDR OLED de 6.1" sem detalhes, Face ID e câmeras testados com 90 dias de garantia.',
    specs: {
      tela: '6.1" Super Retina XDR OLED',
      armazenamento: '128 GB',
      ram: '4 GB',
      bateria: 'Saúde testada >86%',
      camera: 'Dupla 12MP 4K',
      processador: 'A15 Bionic 6-core',
      conexao: '5G, Wi-Fi 6, Bluetooth 5.0',
      garantia: 'Garantia de 90 dias com termo assinado'
    },
    options: {
      cores: ['Meia-Noite', 'Estelar', 'Azul'],
      armazenamento: ['128GB', '256GB']
    },
    price: 3399.00,
    promotionalPrice: 2999.00,
    costPrice: 2400.00,
    stock: 4,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: true,
    warrantyMonths: 3,
    rating: 5,
    reviewsCount: 38
  },
  {
    id: 'prod-2',
    name: 'Samsung Galaxy S24 5G 256GB - Cinza (Seminovo)',
    category: 'Smartphones',
    brand: 'Samsung',
    condition: 'seminovo',
    description: 'Seminovo em estado de novo! Galaxy AI integrada, tela Dynamic AMOLED 2X de 6.2" 120Hz, câmeras de 50MP de altíssima definição e garantia completa de 90 dias Digital Cell.',
    specs: {
      tela: '6.2" Dynamic AMOLED 2X 120Hz',
      armazenamento: '256 GB',
      ram: '8 GB',
      bateria: '4.000 mAh Carregamento Rápido',
      camera: 'Tripla 50MP + 12MP + 10MP Telefoto',
      processador: 'Exynos 2400 Deca-Core',
      conexao: '5G, Wi-Fi 6E, NFC',
      garantia: 'Garantia de 90 dias'
    },
    options: {
      cores: ['Cinza Titânio', 'Preto Ônix'],
      armazenamento: ['256GB']
    },
    price: 3999.00,
    promotionalPrice: 3499.00,
    costPrice: 2800.00,
    stock: 3,
    images: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: true,
    warrantyMonths: 3,
    rating: 4.9,
    reviewsCount: 22
  },
  {
    id: 'prod-3',
    name: 'Xiaomi Redmi Note 13 Pro 5G 256GB / 8GB RAM (Seminovo)',
    category: 'Smartphones',
    brand: 'Xiaomi',
    condition: 'seminovo',
    description: 'Aparelho seminovo selecionado. Câmera de 200MP com OIS, tela AMOLED 1.5K de 120Hz sem arranhões, bateria de 5.100 mAh com excelente autonomia e 90 dias de garantia.',
    specs: {
      tela: '6.67" AMOLED CrystalRes 1.5K 120Hz',
      armazenamento: '256 GB',
      ram: '8 GB (+ expansão virtual)',
      bateria: '5.100 mAh com Turbo 67W',
      camera: 'Tripla 200MP OIS + 8MP + 2MP',
      processador: 'Snapdragon 7s Gen 2',
      conexao: '5G, Dual SIM, NFC',
      garantia: 'Garantia de 90 dias'
    },
    options: {
      cores: ['Preto Meia-Noite', 'Verde Oceano'],
      armazenamento: ['256GB']
    },
    price: 1799.00,
    promotionalPrice: 1549.00,
    costPrice: 1190.00,
    stock: 5,
    images: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: true,
    warrantyMonths: 3,
    rating: 4.8,
    reviewsCount: 45
  },
  {
    id: 'prod-4',
    name: 'iPhone 11 128GB Preto - Seminovo Revisado',
    category: 'Smartphones',
    brand: 'Apple',
    condition: 'seminovo',
    description: 'Aparelho 100% original revisado na bancada Digital Cell Itaquiraí. Bateria com excelente saúde (>85%), sem marcas de uso, Face ID funcionando perfeitamente e garantia de 90 dias.',
    specs: {
      tela: '6.1" Liquid Retina HD',
      armazenamento: '128 GB',
      ram: '4 GB',
      bateria: 'Saúde 87% original testada',
      camera: 'Dupla 12MP Ultra-angular e Grande-angular',
      processador: 'A13 Bionic Neural Engine',
      conexao: '4G LTE, Wi-Fi 6, NFC Apple Pay',
      garantia: 'Garantia de 90 dias com termo assinado'
    },
    options: {
      cores: ['Preto', 'Branco'],
      armazenamento: ['128GB']
    },
    price: 2199.00,
    promotionalPrice: 1890.00,
    costPrice: 1350.00,
    stock: 3,
    images: [
      'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: false,
    featured: true,
    warrantyMonths: 3,
    rating: 4.9,
    reviewsCount: 19
  },
  {
    id: 'prod-5',
    name: 'Motorola Moto G84 5G 256GB - Viva Magenta (Seminovo)',
    category: 'Smartphones',
    brand: 'Motorola',
    condition: 'seminovo',
    description: 'Seminovo conservado com acabamento vegan leather. Tela pOLED 120Hz com cores vivas, som espacial Dolby Atmos e garantia de 90 dias de bancada.',
    specs: {
      tela: '6.55" pOLED FHD+ 120Hz',
      armazenamento: '256 GB',
      ram: '8 GB RAM Boost',
      bateria: '5.000 mAh + TurboPower 33W',
      camera: '50MP OIS Ultra Pixel + 8MP Macro',
      processador: 'Snapdragon 695 5G',
      conexao: '5G, NFC, Entrada P2',
      garantia: 'Garantia de 90 dias'
    },
    options: {
      cores: ['Viva Magenta', 'Azul Grafite'],
      armazenamento: ['256GB']
    },
    price: 1399.00,
    promotionalPrice: 1199.00,
    costPrice: 900.00,
    stock: 4,
    images: [
      'https://images.unsplash.com/photo-1589492477829-5e65395b66cc?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: false,
    featured: false,
    warrantyMonths: 3,
    rating: 4.7,
    reviewsCount: 14
  },
  {
    id: 'prod-6',
    name: 'Carregador Turbo Power 30W USB-C Homologado Anatel',
    category: 'Carregadores & Cabos',
    brand: 'Outros',
    condition: 'seminovo',
    description: 'Carregador turbo com proteção contra sobretensão e curto-circuito. Carrega smartphones com rapidez e segurança. Garantia de 90 dias.',
    specs: {
      tela: 'N/A',
      armazenamento: 'N/A',
      bateria: 'Saída 30W Power Delivery / QC 4.0',
      conexao: 'USB Tipo C',
      garantia: 'Garantia de 90 dias'
    },
    price: 89.90,
    promotionalPrice: 69.90,
    costPrice: 28.00,
    stock: 20,
    images: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: false,
    warrantyMonths: 3,
    rating: 5,
    reviewsCount: 62
  },
  {
    id: 'prod-7',
    name: 'Fone de Ouvido Bluetooth TWS Pro com Cancelamento de Ruído',
    category: 'Acessórios',
    brand: 'Outros',
    condition: 'seminovo',
    description: 'Som estéreo de altíssima definição, graves potentes e cancelamento de ruído. Estojo com carregamento rápido e até 28 horas de autonomia. Garantia de 90 dias.',
    specs: {
      bateria: 'Até 6h contínuas + 24h na case',
      conexao: 'Bluetooth 5.3 Baixa Latência',
      garantia: 'Garantia de 90 dias'
    },
    options: {
      cores: ['Branco Neve', 'Preto Fosco']
    },
    price: 159.00,
    promotionalPrice: 129.00,
    costPrice: 55.00,
    stock: 12,
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: true,
    warrantyMonths: 3,
    rating: 4.8,
    reviewsCount: 41
  },
  {
    id: 'prod-8',
    name: 'Caixa de Som JBL Flip 6 À Prova D\'Água IP67 (Seminova)',
    category: 'Caixas de Som',
    brand: 'JBL',
    condition: 'seminovo',
    description: 'Caixa de som original JBL seminova com som potente de duas vias. Bateria testada para até 12 horas e garantia de 90 dias.',
    specs: {
      bateria: 'Bateria recarregável de até 12 horas',
      conexao: 'Bluetooth 5.1 e JBL PartyBoost',
      garantia: 'Garantia de 90 dias'
    },
    options: {
      cores: ['Preto', 'Azul']
    },
    price: 599.00,
    promotionalPrice: 499.00,
    costPrice: 380.00,
    stock: 3,
    images: [
      'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: false,
    featured: true,
    warrantyMonths: 3,
    rating: 5,
    reviewsCount: 29
  },
  {
    id: 'prod-9',
    name: 'Bateria Original iPhone Linha 11 / 12 / 13 (Com Troca Digital Cell)',
    category: 'Baterias',
    brand: 'Apple',
    condition: 'seminovo',
    description: 'Células de íon de lítio selecionadas com substituição em bancada na loja física da Rua Campo Grande, 1161. Garantia de 90 dias com termo assinado.',
    specs: {
      bateria: 'Capacidade 100% original, 0 ciclos',
      garantia: 'Garantia de 90 dias com termo assinado'
    },
    price: 249.00,
    promotionalPrice: 219.00,
    costPrice: 90.00,
    stock: 12,
    images: [
      'https://images.unsplash.com/photo-1609081219090-a6d8173087ec?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: true,
    featured: false,
    warrantyMonths: 3,
    rating: 4.9,
    reviewsCount: 53
  },
  {
    id: 'prod-10',
    name: 'Tablet Samsung Galaxy Tab A9+ 5G 64GB (Seminovo)',
    category: 'Tablets',
    brand: 'Samsung',
    condition: 'seminovo',
    description: 'Tablet seminovo em perfeito estado. Tela ampla de 11" 90Hz, 4 alto-falantes com Dolby Atmos, ideal para trabalho e estudos. Garantia de 90 dias.',
    specs: {
      tela: '11.0" WUXGA 90Hz Imersiva',
      armazenamento: '64 GB expansível',
      ram: '4 GB',
      bateria: '7.040 mAh',
      garantia: 'Garantia de 90 dias'
    },
    price: 1299.00,
    promotionalPrice: 1099.00,
    costPrice: 850.00,
    stock: 3,
    images: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=800&q=80'
    ],
    bestseller: false,
    featured: false,
    warrantyMonths: 3,
    rating: 4.8,
    reviewsCount: 11
  }
];

export const INITIAL_ASSISTANCE_RECORDS: TechnicalAssistanceOS[] = [
  {
    id: 'os-1',
    protocol: 'OS-2026-8492',
    customerName: 'Lucas Ferreira Mendes',
    customerPhone: '(67) 99654-2110',
    customerEmail: 'lucas.fmendes@gmail.com',
    deviceType: 'Celular',
    brand: 'Apple',
    model: 'iPhone 12 Pro 128GB',
    defectDescription: 'Aparelho caiu no asfalto. Vidro frontal trincado com toque falhando na parte inferior.',
    status: 'pronto_retirada',
    partsCost: 320.00,
    laborCost: 150.00,
    totalCost: 470.00,
    technicianNotes: 'Substituição completa do módulo frontal OLED premium concluída. Testes de FaceID, TrueTone e touch 100% calibrados. Garantia de 90 dias.',
    customerApproved: true,
    createdAt: '2026-10-28T09:15:00Z',
    updatedAt: '2026-10-29T16:30:00Z'
  },
  {
    id: 'os-2',
    protocol: 'OS-2026-8501',
    customerName: 'Mariana Souza Rocha',
    customerPhone: '(67) 99812-4433',
    deviceType: 'Celular',
    brand: 'Samsung',
    model: 'Galaxy S21',
    defectDescription: 'Não carrega mais pelo cabo, somente por indução. Conector Tipo C com folga.',
    status: 'em_reparo',
    partsCost: 65.00,
    laborCost: 90.00,
    totalCost: 155.00,
    technicianNotes: 'Desoxidação e troca da sub-placa dock de carga Type-C original. Garantia de 90 dias.',
    customerApproved: true,
    createdAt: '2026-10-29T14:20:00Z',
    updatedAt: '2026-10-30T10:00:00Z'
  },
  {
    id: 'os-3',
    protocol: 'OS-2026-8515',
    customerName: 'Carlos Eduardo Nogueira',
    customerPhone: '(67) 99123-8877',
    deviceType: 'Tablet',
    brand: 'Samsung',
    model: 'Galaxy Tab A7 Lite',
    defectDescription: 'Bateria descarrega com 40%.',
    status: 'aguardando_aprovacao',
    partsCost: 120.00,
    laborCost: 80.00,
    totalCost: 200.00,
    technicianNotes: 'Substituição de bateria de alta densidade recomendada com garantia de 90 dias.',
    customerApproved: null,
    createdAt: '2026-10-30T08:10:00Z',
    updatedAt: '2026-10-30T09:40:00Z'
  }
];

export const INITIAL_WARRANTIES: Warranty[] = [
  {
    id: 'war-1',
    protocol: 'GAR-7741',
    imeiOrSerial: '356892110482910',
    productName: 'iPhone 13 128GB - Meia-Noite (Seminovo)',
    customerName: 'Beatriz Almeida Lima',
    customerPhone: '(67) 98450-1122',
    customerCpf: '042.***.***-89',
    purchaseDate: '2026-09-01',
    expirationDate: '2026-12-01',
    warrantyMonths: 3,
    condition: 'seminovo',
    status: 'ativa',
    terms: 'Garantia legal de 90 dias assegurada pela Digital Cell Celulares cobrindo funcionamento eletrônico, peças e bancada técnica conforme laudo.'
  },
  {
    id: 'war-2',
    protocol: 'GAR-6510',
    imeiOrSerial: '864290041288341',
    productName: 'iPhone 11 128GB - Seminovo Revisado',
    customerName: 'Marcos Vinicius Duarte',
    customerPhone: '(67) 99933-7766',
    customerCpf: '710.***.***-15',
    purchaseDate: '2026-09-15',
    expirationDate: '2026-12-15',
    warrantyMonths: 3,
    condition: 'seminovo',
    status: 'ativa',
    terms: 'Garantia de 90 dias cobrindo placa, bateria e componentes eletrônicos revisados pela bancada Digital Cell.'
  },
  {
    id: 'war-3',
    protocol: 'GAR-4209',
    imeiOrSerial: '352901048821940',
    productName: 'Xiaomi Redmi Note 12 (Seminovo)',
    customerName: 'Patricia Guedes Ribeiro',
    customerPhone: '(67) 99870-5544',
    purchaseDate: '2026-05-10',
    expirationDate: '2026-08-10',
    warrantyMonths: 3,
    condition: 'seminovo',
    status: 'expirada',
    terms: 'Garantia de 90 dias finalizada.'
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  {
    code: 'DIGITAL10',
    discountType: 'percentage',
    discountValue: 10,
    minPurchase: 100,
    active: true
  },
  {
    code: 'BEMVINDO',
    discountType: 'fixed',
    discountValue: 20,
    minPurchase: 80,
    active: true
  },
  {
    code: 'CLIENTEITAQUIRAI',
    discountType: 'percentage',
    discountValue: 5,
    minPurchase: 50,
    active: true
  }
];
