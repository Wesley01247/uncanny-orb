import React, { useState } from 'react';
import { 
  Wrench, 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Camera, 
  FileText, 
  ShieldCheck, 
  ThumbsUp, 
  ThumbsDown, 
  PhoneCall, 
  Check, 
  ArrowRight,
  Smartphone,
  Sparkles
} from 'lucide-react';
import { TechnicalAssistanceOS, OSStatus } from '../types';
import { STORE_INFO } from '../data/mockData';

interface TechnicalAssistanceProps {
  osList: TechnicalAssistanceOS[];
  onCreateOS: (newOS: TechnicalAssistanceOS) => void;
  onUpdateOSStatus: (protocol: string, status: OSStatus, approved?: boolean) => void;
}

export const TechnicalAssistance: React.FC<TechnicalAssistanceProps> = ({
  osList,
  onCreateOS,
  onUpdateOSStatus
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'solicitar' | 'consultar'>('solicitar');
  
  // New OS Form
  const [deviceType, setDeviceType] = useState<'Celular' | 'Tablet' | 'Outro'>('Celular');
  const [brand, setBrand] = useState('Apple');
  const [model, setModel] = useState('');
  const [defectQuick, setDefectQuick] = useState('');
  const [defectDetails, setDefectDetails] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('(67) 9');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [generatedProtocol, setGeneratedProtocol] = useState<string | null>(null);

  // Search Protocol state
  const [searchProtocol, setSearchProtocol] = useState('');
  const [foundOS, setFoundOS] = useState<TechnicalAssistanceOS | null>(null);
  const [searchError, setSearchError] = useState('');

  const defectQuickOptions = [
    'Tela trincada / touch não responde',
    'Bateria descarrega rápido / viciada',
    'Aparelho não liga / tela preta',
    'Conector de carga frouxo / não carrega',
    'Aparelho caiu na água / desoxidação',
    'Câmera traseira/frontal com defeito',
    'Aparelho travado no logo / reiniciar'
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitNewOS = (e: React.FormEvent) => {
    e.preventDefault();
    if (!model.trim() || !customerName.trim() || !customerPhone.trim()) {
      alert('Por favor, preencha o modelo do aparelho e seus dados de contato.');
      return;
    }

    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const protocol = `OS-2026-${randomNum}`;
    const fullDefect = defectQuick ? `${defectQuick} - ${defectDetails}` : defectDetails;

    const newOS: TechnicalAssistanceOS = {
      id: `os-${Date.now()}`,
      protocol,
      customerName,
      customerPhone,
      deviceType,
      brand,
      model,
      defectDescription: fullDefect,
      photoUrl: photoPreview || undefined,
      status: 'recebido',
      partsCost: 0,
      laborCost: 0,
      totalCost: 0,
      technicianNotes: 'Aparelho pré-cadastrado via site Digital Cell. Aguardando entrada física em bancada na loja de Itaquiraí.',
      customerApproved: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onCreateOS(newOS);
    setGeneratedProtocol(protocol);
    setFoundOS(newOS);
    setActiveSubTab('consultar');
  };

  const handleSearchOS = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    const term = searchProtocol.trim().toUpperCase();

    if (!term) return;

    const match = osList.find(
      os => os.protocol.toUpperCase() === term || os.customerPhone.replace(/\D/g, '').includes(term.replace(/\D/g, ''))
    );

    if (match) {
      setFoundOS(match);
    } else {
      setSearchError('Ordem de Serviço não encontrada. Verifique o número do protocolo (ex: OS-2026-8492) ou telefone.');
      setFoundOS(null);
    }
  };

  const getStatusStepIndex = (status: OSStatus) => {
    switch (status) {
      case 'recebido': return 1;
      case 'analise_tecnica': return 2;
      case 'orcamento_pronto':
      case 'aguardando_aprovacao': return 3;
      case 'aprovado':
      case 'em_reparo': return 4;
      case 'testes_finais': return 5;
      case 'pronto_retirada': return 6;
      case 'entregue': return 7;
      case 'recusado': return -1;
      default: return 1;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      
      {/* Module Title Banner */}
      <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-xs font-bold uppercase">
          <Wrench className="w-4 h-4 text-[#f4c430]" />
          <span>Assistência Técnica Especializada em Itaquiraí</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          Consertos Rápidos com Garantia e Peças de Alta Qualidade
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Troca de telas OLED/Incell, baterias originais, conectores de carga, banho químico anti-oxidação e reparo em placas para Apple, Samsung, Xiaomi e Motorola.
        </p>
      </div>

      {/* Sub Tabs Selector */}
      <div className="flex justify-center mb-8">
        <div className="inline-flex p-1.5 rounded-2xl bg-slate-900 border border-white/10">
          <button
            onClick={() => setActiveSubTab('solicitar')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeSubTab === 'solicitar'
                ? 'bg-[#1fa64b] text-white shadow-md shadow-[#1fa64b]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Solicitar Orçamento Grátis</span>
          </button>

          <button
            onClick={() => setActiveSubTab('consultar')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeSubTab === 'consultar'
                ? 'bg-[#1fa64b] text-white shadow-md shadow-[#1fa64b]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Consultar Minha OS (Protocolo)</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: Form Solicitar Orçamento */}
      {activeSubTab === 'solicitar' && (
        <div className="max-w-2xl mx-auto bg-[#121826] rounded-3xl border border-[#1fa64b]/30 p-5 sm:p-8 shadow-2xl">
          <form onSubmit={handleSubmitNewOS} className="space-y-5">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">Dados do Aparelho</h3>
              <p className="text-xs text-slate-400 mb-3">
                Informe os detalhes do aparelho para receber nossa pré-análise e orçamento prévio.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Tipo de Dispositivo</label>
                  <select
                    value={deviceType}
                    onChange={(e: any) => setDeviceType(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl p-2.5 text-white outline-none focus:border-[#1fa64b]"
                  >
                    <option value="Celular">Smartphone / Celular</option>
                    <option value="Tablet">Tablet / iPad</option>
                    <option value="Outro">Outro Dispositivo</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Marca</label>
                  <select
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl p-2.5 text-white outline-none focus:border-[#1fa64b]"
                  >
                    <option value="Apple">Apple (iPhone)</option>
                    <option value="Samsung">Samsung</option>
                    <option value="Xiaomi">Xiaomi / Poco / Redmi</option>
                    <option value="Motorola">Motorola</option>
                    <option value="Realme">Realme</option>
                    <option value="Outro">Outra Marca</option>
                  </select>
                </div>
              </div>

              <div className="mt-3">
                <label className="block text-slate-300 text-xs mb-1">Modelo Exato *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: iPhone 13 128GB ou Galaxy A54 ou Redmi Note 12"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2.5 text-white text-xs outline-none focus:border-[#1fa64b]"
                />
              </div>
            </div>

            {/* Defect Quick Select */}
            <div>
              <label className="block text-slate-300 text-xs font-semibold mb-1.5">
                Qual é o principal defeito? (Selecione uma opção comum):
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {defectQuickOptions.map((opt) => (
                  <button
                    type="button"
                    key={opt}
                    onClick={() => setDefectQuick(opt)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                      defectQuick === opt
                        ? 'bg-[#1fa64b] border-[#1fa64b] text-white'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/30'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>

              <textarea
                rows={3}
                required
                placeholder="Descreva detalhadamente o que aconteceu (ex: caiu no chão, parou de funcionar o touch na parte de baixo, descarrega em 2 horas...)"
                value={defectDetails}
                onChange={(e) => setDefectDetails(e.target.value)}
                className="w-full bg-slate-900 border border-white/15 rounded-xl p-3 text-white text-xs outline-none focus:border-[#1fa64b]"
              />
            </div>

            {/* Photo Attachment Simulation */}
            <div>
              <label className="block text-slate-300 text-xs font-semibold mb-1">
                Foto do Aparelho / Defeito (opcional):
              </label>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-white/20 text-slate-300 hover:text-white cursor-pointer text-xs font-medium">
                  <Camera className="w-4 h-4 text-[#1fa64b]" />
                  <span>Escolher Foto ou Tirar Agora</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
                {photoPreview && (
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-[#1fa64b]">
                    <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotoPreview(null)}
                      className="absolute inset-0 bg-black/50 text-white text-[10px] flex items-center justify-center"
                    >
                      X
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Customer Details */}
            <div className="pt-2 border-t border-white/10">
              <h4 className="text-xs font-bold text-[#1fa64b] uppercase tracking-wider mb-2">
                Seus Dados para Contato
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Seu Nome *</label>
                  <input
                    type="text"
                    required
                    placeholder="Nome completo"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">WhatsApp de Contato em Itaquiraí *</label>
                  <input
                    type="text"
                    required
                    placeholder="(67) 98135-9433"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#1fa64b] to-[#168a3d] hover:brightness-110 text-white font-bold text-sm shadow-lg shadow-[#1fa64b]/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-[#f4c430]" />
              <span>Gerar Protocolo e Enviar Solicitação</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* SUBTAB 2: Consultar OS */}
      {activeSubTab === 'consultar' && (
        <div className="max-w-3xl mx-auto space-y-6">
          
          {/* Search Protocol Box */}
          <div className="bg-[#121826] p-5 sm:p-6 rounded-3xl border border-white/10 shadow-xl">
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Search className="w-4 h-4 text-[#1fa64b]" />
              <span>Digite o Protocolo da sua Ordem de Serviço</span>
            </h3>
            <form onSubmit={handleSearchOS} className="flex gap-2">
              <input
                type="text"
                placeholder="Exemplo: OS-2026-8492 ou seu WhatsApp"
                value={searchProtocol}
                onChange={(e) => setSearchProtocol(e.target.value)}
                className="flex-1 bg-slate-900 border border-white/15 rounded-xl px-4 py-2.5 text-white text-xs sm:text-sm outline-none focus:border-[#1fa64b]"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs sm:text-sm font-bold transition-all cursor-pointer"
              >
                Buscar
              </button>
            </form>
            {searchError && (
              <p className="text-xs text-rose-400 mt-2">{searchError}</p>
            )}

            {/* Quick Demo OS Buttons */}
            <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-slate-400">
              <span>Exemplos em andamento:</span>
              <button
                type="button"
                onClick={() => {
                  const target = osList.find(o => o.protocol === 'OS-2026-8492');
                  if (target) setFoundOS(target);
                }}
                className="text-[#f4c430] hover:underline font-mono"
              >
                OS-2026-8492 (Pronto)
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => {
                  const target = osList.find(o => o.protocol === 'OS-2026-8515');
                  if (target) setFoundOS(target);
                }}
                className="text-[#38bdf8] hover:underline font-mono"
              >
                OS-2026-8515 (Aguardando Aprovação)
              </button>
            </div>
          </div>

          {/* OS Result Details & Timeline */}
          {foundOS && (
            <div className="bg-[#121826] rounded-3xl border border-[#1fa64b]/30 p-5 sm:p-8 shadow-2xl space-y-6">
              
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#f4c430] bg-[#f4c430]/15 px-2.5 py-1 rounded-md">
                      {foundOS.protocol}
                    </span>
                    <span className="text-xs text-slate-400">
                      Entrada: {new Date(foundOS.createdAt).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-white mt-1">
                    {foundOS.brand} {foundOS.model}
                  </h3>
                  <p className="text-xs text-slate-300">
                    Cliente: <strong>{foundOS.customerName}</strong> ({foundOS.customerPhone})
                  </p>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-xs text-slate-400 block">Status Atual:</span>
                  <span className="text-sm font-extrabold uppercase text-[#1fa64b]">
                    {foundOS.status.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {/* Visual Stages Progress */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4">
                  Acompanhamento Passo a Passo
                </h4>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className={`p-2.5 rounded-xl border ${
                    getStatusStepIndex(foundOS.status) >= 1
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-white font-bold'
                      : 'bg-slate-900 border-white/10 text-slate-500'
                  }`}>
                    1. Entrada na Loja
                  </div>

                  <div className={`p-2.5 rounded-xl border ${
                    getStatusStepIndex(foundOS.status) >= 2
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-white font-bold'
                      : 'bg-slate-900 border-white/10 text-slate-500'
                  }`}>
                    2. Laudo Técnico
                  </div>

                  <div className={`p-2.5 rounded-xl border ${
                    getStatusStepIndex(foundOS.status) >= 4
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-white font-bold'
                      : 'bg-slate-900 border-white/10 text-slate-500'
                  }`}>
                    3. Reparo em Bancada
                  </div>

                  <div className={`p-2.5 rounded-xl border ${
                    getStatusStepIndex(foundOS.status) >= 6
                      ? 'bg-[#f4c430]/20 border-[#f4c430] text-[#f4c430] font-black'
                      : 'bg-slate-900 border-white/10 text-slate-500'
                  }`}>
                    4. Pronto p/ Retirada
                  </div>
                </div>
              </div>

              {/* Technical Diagnosis & Defect */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-1">
                  <span className="text-slate-400 font-bold block">Defeito Relatado:</span>
                  <p className="text-slate-200 leading-relaxed">{foundOS.defectDescription}</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-1">
                  <span className="text-slate-400 font-bold block">Laudo & Notas do Técnico:</span>
                  <p className="text-[#38e370] leading-relaxed">
                    {foundOS.technicianNotes || 'Em análise por nossa equipe técnica.'}
                  </p>
                </div>
              </div>

              {/* Budget Breakdown & Approval Callout */}
              {foundOS.totalCost > 0 && (
                <div className="p-4 rounded-2xl bg-[#0b2c5a]/40 border border-[#1fa64b]/30 space-y-3">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <span className="text-xs text-slate-300 font-bold block">Orçamento Detalhado:</span>
                      <span className="text-xs text-slate-400">
                        Peças: R$ {foundOS.partsCost.toFixed(2)} | Mão de obra especializada: R$ {foundOS.laborCost.toFixed(2)}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-slate-400 block">Total do Serviço:</span>
                      <span className="text-xl font-black text-[#f4c430]">
                        R$ {foundOS.totalCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  {/* Customer Approval Buttons */}
                  {foundOS.status === 'aguardando_aprovacao' && (
                    <div className="pt-2 border-t border-white/10 flex flex-wrap gap-2 items-center justify-between">
                      <span className="text-xs text-amber-300 font-semibold">
                        Aguardando sua autorização para iniciar o reparo:
                      </span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            onUpdateOSStatus(foundOS.protocol, 'em_reparo', true);
                            setFoundOS({
                              ...foundOS,
                              status: 'em_reparo',
                              customerApproved: true
                            });
                          }}
                          className="px-4 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow"
                        >
                          <ThumbsUp className="w-3.5 h-3.5" />
                          <span>Aprovar Orçamento</span>
                        </button>

                        <button
                          onClick={() => {
                            onUpdateOSStatus(foundOS.protocol, 'recusado', false);
                            setFoundOS({
                              ...foundOS,
                              status: 'recusado',
                              customerApproved: false
                            });
                          }}
                          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                        >
                          <ThumbsDown className="w-3.5 h-3.5" />
                          <span>Recusar</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {foundOS.customerApproved === true && (
                    <div className="text-xs text-[#1fa64b] font-bold flex items-center gap-1.5 pt-1">
                      <Check className="w-4 h-4" />
                      <span>Orçamento aprovado pelo cliente! Serviço em andamento.</span>
                    </div>
                  )}
                </div>
              )}

              {/* Direct WhatsApp Callout */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <span className="text-slate-400 text-center sm:text-left">
                  Endereço para entrega/retirada: <strong>Av. Mato Grosso, 850 - Centro, Itaquiraí-MS</strong>
                </span>
                <a
                  href={`https://wa.me/${STORE_INFO.phone}?text=Olá,%20gostaria%20de%20falar%20sobre%20a%20OS%20${foundOS.protocol}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd59] text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Falar com o Técnico no WhatsApp</span>
                </a>
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
};
