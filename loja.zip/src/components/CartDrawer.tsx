import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Tag, 
  Truck, 
  Store, 
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { CartItem, Coupon } from '../types';
import { INITIAL_COUPONS, STORE_INFO } from '../data/mockData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
  onProceedToCheckout: (appliedCoupon: Coupon | null, shippingFee: number, deliveryType: 'retirada') => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout
}) => {
  if (!isOpen) return null;

  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');
  const deliveryType = 'retirada';
  const shippingFee = 0;

  const subtotal = items.reduce((acc, item) => {
    const unitPrice = item.product.promotionalPrice || item.product.price;
    return acc + unitPrice * item.quantity;
  }, 0);

  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountType === 'percentage') {
      discount = (subtotal * appliedCoupon.discountValue) / 100;
    } else {
      discount = appliedCoupon.discountValue;
    }
  }

  const grandTotal = Math.max(0, subtotal - discount);

  const handleApplyCoupon = () => {
    setCouponError('');
    const cleanCode = couponCode.trim().toUpperCase();
    const found = INITIAL_COUPONS.find(c => c.code === cleanCode && c.active);

    if (!found) {
      setCouponError('Cupom inválido ou expirado.');
      setAppliedCoupon(null);
      return;
    }

    if (subtotal < found.minPurchase) {
      setCouponError(`Pedido mínimo para este cupom é de R$ ${found.minPurchase.toFixed(2)}.`);
      setAppliedCoupon(null);
      return;
    }

    setAppliedCoupon(found);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-[#121826] text-white h-full shadow-2xl flex flex-col border-l border-[#1fa64b]/30 animate-in slide-in-from-right duration-250"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#0b2c5a]/40">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#f4c430]" />
            <h2 className="text-base sm:text-lg font-bold">Carrinho de Compras</h2>
            <span className="bg-[#1fa64b] text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {items.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
              <ShoppingBag className="w-12 h-12 text-slate-600" />
              <p className="text-base font-semibold text-slate-200">Seu carrinho está vazio</p>
              <p className="text-xs text-slate-400 max-w-xs">
                Navegue pelas nossas ofertas em Itaquiraí e adicione smartphones ou acessórios para finalizar sua compra.
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs font-bold transition-colors"
              >
                Ver Produtos
              </button>
            </div>
          ) : (
            items.map((item, index) => {
              const unitPrice = item.product.promotionalPrice || item.product.price;
              return (
                <div
                  key={`${item.product.id}-${index}`}
                  className="p-3 rounded-xl bg-slate-900/70 border border-white/10 flex gap-3 items-center"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-slate-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                      {item.product.name}
                    </h4>
                    {(item.selectedColor || item.selectedStorage) && (
                      <p className="text-[11px] text-slate-400">
                        {item.selectedColor} {item.selectedStorage ? `• ${item.selectedStorage}` : ''}
                      </p>
                    )}
                    <div className="text-xs font-extrabold text-[#1fa64b] mt-0.5">
                      R$ {(unitPrice * item.quantity).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </div>

                    {/* Quantity Selector */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center bg-slate-800 rounded-lg border border-white/15 px-1 py-0.5 text-xs">
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                          className="px-1.5 py-0.5 text-slate-300 hover:text-white"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 font-bold text-white">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                          className="px-1.5 py-0.5 text-slate-300 hover:text-white"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => onRemoveItem(index)}
                        className="text-slate-400 hover:text-rose-400 p-1 text-xs"
                        title="Remover produto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Drawer Footer & Calculations */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-white/10 bg-[#080d19] space-y-3.5">
            
            {/* Pickup Method */}
            <div className="p-3 rounded-xl bg-slate-900 border border-[#1fa64b]/30">
              <span className="text-xs font-bold text-slate-300 block mb-1">
                Recebimento em Itaquiraí-MS:
              </span>
              <div className="flex items-center gap-2 text-xs text-[#1fa64b] font-bold">
                <Store className="w-4 h-4 shrink-0" />
                <span>Retirada na Loja ({STORE_INFO.address}) — Grátis</span>
              </div>
            </div>

            {/* Coupon Box */}
            <div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Cupom (ex: DIGITAL10)"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full bg-slate-900 text-white placeholder-slate-500 pl-8 pr-2 py-1.5 rounded-lg border border-white/15 text-xs outline-none focus:border-[#1fa64b]"
                  />
                  <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                </div>
                <button
                  onClick={handleApplyCoupon}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-[#f4c430] border border-white/10"
                >
                  Aplicar
                </button>
              </div>
              {couponError && <p className="text-[11px] text-rose-400 mt-1">{couponError}</p>}
              {appliedCoupon && (
                <div className="flex items-center justify-between text-[11px] text-[#1fa64b] mt-1 font-semibold">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Cupom {appliedCoupon.code} aplicado!
                  </span>
                  <button 
                    onClick={() => { setAppliedCoupon(null); setCouponCode(''); }}
                    className="text-slate-400 hover:text-white underline text-[10px]"
                  >
                    Remover
                  </button>
                </div>
              )}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-white/10">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>R$ {subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-[#1fa64b]">
                  <span>Desconto cupom:</span>
                  <span>- R$ {discount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Retirada no Balcão:</span>
                <span className="text-[#1fa64b] font-bold">Grátis</span>
              </div>
              <div className="flex justify-between text-sm sm:text-base font-black text-white pt-1 border-t border-white/10">
                <span>Total a Pagar:</span>
                <span className="text-[#f4c430]">
                  R$ {grandTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {/* Proceed to Checkout Button */}
            <button
              onClick={() => {
                onProceedToCheckout(appliedCoupon, shippingFee, deliveryType);
              }}
              className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-[#1fa64b] to-[#168a3d] hover:brightness-110 text-white flex items-center justify-center gap-2 shadow-lg shadow-[#1fa64b]/30 cursor-pointer"
            >
              <span>Finalizar Compra</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
