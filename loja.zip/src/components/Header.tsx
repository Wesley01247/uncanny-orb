import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Wrench, 
  ShieldCheck, 
  Search, 
  Phone, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Package, 
  Lock, 
  Bot
} from 'lucide-react';
import { STORE_INFO } from '../data/mockData';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  openCart: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  isDark: boolean;
  toggleTheme: () => void;
  openChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  openCart,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  isDark,
  toggleTheme,
  openChat
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const categories = [
    'Todos',
    'Smartphones',
    'Tablets',
    'Acessórios',
    'Baterias',
    'Carregadores & Cabos',
    'Caixas de Som'
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#0b2c5a]/95 text-white border-b border-[#1fa64b]/30 shadow-lg">
      {/* Top Notification Bar */}
      <div className="bg-gradient-to-r from-[#071b37] via-[#0b2c5a] to-[#124222] px-4 py-1.5 text-xs border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-[#1fa64b] animate-ping" />
            <span className="font-medium text-slate-200">
              Loja Física em Itaquiraí-MS | Rua Campo Grande, 1161 - Centro
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-300">
            <a 
              href={STORE_INFO.whatsappUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[#25D366] hover:text-[#2ad160] font-semibold transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>WhatsApp: {STORE_INFO.phoneFormatted}</span>
            </a>
            <span className="hidden sm:inline text-white/30">|</span>
            <span className="hidden sm:inline text-[#f4c430] font-medium">
              Pix PagBank com Liberação Imediata
            </span>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          
          {/* Logo & Store Identity */}
          <button 
            onClick={() => { setActiveTab('catalogo'); setSelectedCategory('Todos'); }}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="relative">
              <img 
                src={STORE_INFO.logoUrl} 
                alt="Digital Cell Celulares" 
                className="h-12 w-12 md:h-14 md:w-14 rounded-full object-cover border-2 border-[#1fa64b] shadow-md shadow-[#1fa64b]/30 group-hover:scale-105 transition-transform" 
              />
              <span className="absolute -bottom-1 -right-1 bg-[#1fa64b] text-[10px] font-bold text-white px-1.5 py-0.2 rounded-full border border-white/40">
                MS
              </span>
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg md:text-xl tracking-tight text-white group-hover:text-[#1fa64b] transition-colors">
                  DIGITAL<span className="text-[#f4c430]">CELL</span>
                </span>
              </div>
              <p className="text-[11px] text-[#1fa64b] font-bold tracking-widest uppercase">
                Assistência & Seminovos
              </p>
            </div>
          </button>

          {/* Search Bar */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar iPhone, Galaxy, Xiaomi seminovo, telas, baterias..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#121826]/80 text-white placeholder-slate-400 pl-10 pr-4 py-2 rounded-full border border-white/15 focus:border-[#1fa64b] focus:ring-2 focus:ring-[#1fa64b]/20 outline-none text-sm transition-all"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                >
                  Limpar
                </button>
              )}
            </div>
          </div>

          {/* Action Navigation */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* AI Support Bot Trigger with Robozinho Icon */}
            <button
              onClick={openChat}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#1fa64b] to-[#128037] hover:brightness-110 text-white text-xs font-semibold shadow-md shadow-[#1fa64b]/20 transition-all cursor-pointer"
              title="Atendente Virtual IA Digital Cell"
            >
              <Bot className="w-4 h-4" />
              <span className="hidden lg:inline">Suporte IA</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full bg-[#121826]/80 border border-white/10 hover:border-[#1fa64b] text-slate-300 hover:text-white transition-all cursor-pointer"
              title={isDark ? "Modo Claro" : "Modo Escuro"}
            >
              {isDark ? <Sun className="w-4 h-4 text-[#f4c430]" /> : <Moon className="w-4 h-4 text-cyan-300" />}
            </button>

            {/* Cart Button */}
            <button
              onClick={openCart}
              className="relative flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#f4c430] hover:bg-[#ffcf3d] text-[#0b2c5a] font-bold text-sm shadow-md shadow-amber-500/20 transition-all cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Carrinho</span>
              {cartCount > 0 && (
                <span className="bg-[#e11d48] text-white text-xs font-black px-2 py-0.5 rounded-full -ml-1 animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg bg-[#121826] text-white hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center justify-between border-t border-white/10 mt-3 pt-2 text-sm">
          <div className="flex items-center gap-6">
            <button
              onClick={() => { setActiveTab('catalogo'); }}
              className={`font-medium py-1 transition-colors ${
                activeTab === 'catalogo' 
                  ? 'text-[#f4c430] border-b-2 border-[#f4c430] font-bold' 
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              Seminovos & Ofertas
            </button>

            <button
              onClick={() => setActiveTab('assistencia')}
              className={`flex items-center gap-1.5 font-medium py-1 transition-colors ${
                activeTab === 'assistencia' 
                  ? 'text-[#f4c430] border-b-2 border-[#f4c430] font-bold' 
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              <Wrench className="w-4 h-4 text-[#1fa64b]" />
              <span>Assistência Técnica (OS)</span>
            </button>

            <button
              onClick={() => setActiveTab('garantias')}
              className={`flex items-center gap-1.5 font-medium py-1 transition-colors ${
                activeTab === 'garantias' 
                  ? 'text-[#f4c430] border-b-2 border-[#f4c430] font-bold' 
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-[#1fa64b]" />
              <span>Garantia 90 Dias & IMEI</span>
            </button>

            <button
              onClick={() => setActiveTab('pedidos')}
              className={`flex items-center gap-1.5 font-medium py-1 transition-colors ${
                activeTab === 'pedidos' 
                  ? 'text-[#f4c430] border-b-2 border-[#f4c430] font-bold' 
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              <Package className="w-4 h-4 text-[#38bdf8]" />
              <span>Acompanhar Retirada</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1.5 text-xs px-3 py-1 rounded-md font-semibold transition-colors ${
                activeTab === 'admin'
                  ? 'bg-[#1fa64b] text-white'
                  : 'bg-white/10 hover:bg-white/20 text-slate-200'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Painel Gerencial</span>
            </button>
          </div>
        </nav>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar seminovos em Itaquiraí..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121826] text-white placeholder-slate-400 pl-10 pr-4 py-2 rounded-lg border border-white/15 focus:border-[#1fa64b] outline-none text-sm"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-3 pt-3 border-t border-white/10 flex flex-col gap-2 pb-2">
            <button
              onClick={() => { setActiveTab('catalogo'); setMobileMenuOpen(false); }}
              className={`text-left px-3 py-2 rounded-lg text-sm font-medium ${
                activeTab === 'catalogo' ? 'bg-[#1fa64b] text-white' : 'text-slate-200 hover:bg-white/5'
              }`}
            >
              Seminovos & Ofertas
            </button>
            <button
              onClick={() => { setActiveTab('assistencia'); setMobileMenuOpen(false); }}
              className={`text-left px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                activeTab === 'assistencia' ? 'bg-[#1fa64b] text-white' : 'text-slate-200 hover:bg-white/5'
              }`}
            >
              <Wrench className="w-4 h-4 text-[#f4c430]" />
              Assistência Técnica (OS)
            </button>
            <button
              onClick={() => { setActiveTab('garantias'); setMobileMenuOpen(false); }}
              className={`text-left px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                activeTab === 'garantias' ? 'bg-[#1fa64b] text-white' : 'text-slate-200 hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-[#f4c430]" />
              Consulta de Garantia (90 Dias)
            </button>
            <button
              onClick={() => { setActiveTab('pedidos'); setMobileMenuOpen(false); }}
              className={`text-left px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                activeTab === 'pedidos' ? 'bg-[#1fa64b] text-white' : 'text-slate-200 hover:bg-white/5'
              }`}
            >
              <Package className="w-4 h-4 text-[#38bdf8]" />
              Acompanhar Retirada
            </button>
            <button
              onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
              className={`text-left px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                activeTab === 'admin' ? 'bg-[#1fa64b] text-white' : 'text-slate-200 hover:bg-white/5'
              }`}
            >
              <Lock className="w-4 h-4 text-[#f4c430]" />
              Painel Administrativo
            </button>
          </div>
        )}

        {/* Sub-bar Categories Filter (Visible on Catalog Tab) */}
        {activeTab === 'catalogo' && (
          <div className="flex items-center gap-2 overflow-x-auto py-2.5 mt-1 border-t border-white/5 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`whitespace-nowrap px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#1fa64b] text-white shadow-md shadow-[#1fa64b]/30'
                    : 'bg-[#121826]/70 text-slate-300 hover:text-white hover:bg-[#121826]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
};
