import React, { useState } from 'react';
import { 
  X, 
  ShoppingCart, 
  ShieldCheck, 
  Truck, 
  Check, 
  Star, 
  PhoneCall, 
  MapPin,
  Cpu,
  Layers,
  HardDrive,
  Trash2
} from 'lucide-react';
import { Product } from '../types';
import { STORE_INFO } from '../data/mockData';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, color?: string, storage?: string) => void;
  onBuyNow: (product: Product, quantity: number, color?: string, storage?: string) => void;
  onDeleteProduct?: (productId: string) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onDeleteProduct
}) => {
  if (!product) return null;

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product.options?.cores?.[0]
  );
  const [selectedStorage, setSelectedStorage] = useState<string | undefined>(
    product.options?.armazenamento?.[0]
  );
  const [quantity, setQuantity] = useState(1);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const isAdmin = typeof window !== 'undefined' && sessionStorage.getItem('digitalcell_admin_auth') === 'true';

  const hasPromo = product.promotionalPrice && product.promotionalPrice < product.price;
  const currentPrice = hasPromo ? product.promotionalPrice! : product.price;

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Olá! Gostaria de mais informações sobre o produto: *${product.name}* (R$ ${currentPrice.toFixed(2)}) na loja de Itaquiraí.`
    );
    window.open(`https://wa.me/${STORE_INFO.phone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative w-full max-w-4xl bg-[#121826] text-white rounded-2xl sm:rounded-3xl border border-[#1fa64b]/30 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 sm:p-8">
          
          {/* Gallery Column */}
          <div className="md:col-span-5 space-y-3">
            <div className="w-full h-64 sm:h-80 rounded-2xl overflow-hidden bg-slate-900 border border-white/10 flex items-center justify-center relative">
              <img
                src={product.images[selectedImage] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#f4c430] text-[#0b2c5a] text-[11px] font-black uppercase tracking-wider shadow">
                {product.category === 'Smartphones' ? 'Seminovo Revisado' : 'Garantia 90 Dias'}
              </span>
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === idx ? 'border-[#1fa64b] scale-105' : 'border-white/20 opacity-70'
                    }`}
                  >
                    <img src={img} alt="Miniatura" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Quick Guarantee Box */}
            <div className="p-3.5 rounded-xl bg-[#0b2c5a]/40 border border-[#1fa64b]/30 text-xs text-slate-300 space-y-1.5">
              <div className="flex items-center gap-2 text-[#1fa64b] font-bold">
                <ShieldCheck className="w-4 h-4 text-[#f4c430]" />
                <span>Garantia Digital Cell: 90 Dias Assegurados</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Aparelho com nota, termo assinado e consulta direta de IMEI pelo site da loja.
              </p>
            </div>
          </div>

          {/* Details Column */}
          <div className="md:col-span-7 flex flex-col justify-between space-y-4">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="font-semibold text-[#1fa64b] uppercase">
                  {product.brand} • {product.category}
                </span>
                <div className="flex items-center gap-1 text-[#f4c430]">
                  <Star className="w-3.5 h-3.5 fill-[#f4c430]" />
                  <span className="font-bold text-white">{product.rating.toFixed(1)}</span>
                  <span className="text-slate-400">({product.reviewsCount} avaliações)</span>
                </div>
              </div>

              <h2 className="text-xl sm:text-2xl font-extrabold text-white leading-tight">
                {product.name}
              </h2>

              {/* Price Block */}
              <div className="mt-3 flex items-baseline gap-3">
                <span className="text-2xl sm:text-3xl font-black text-white">
                  R$ {currentPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                {hasPromo && (
                  <span className="text-sm text-slate-400 line-through">
                    R$ {product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                )}
                <span className="text-xs font-bold text-[#1fa64b] bg-[#1fa64b]/15 px-2 py-0.5 rounded-md">
                  Pix PagBank
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Em até 12x de R$ {(currentPrice / 10).toFixed(2).replace('.', ',')} no cartão ou à vista no Pix com liberação imediata.
              </p>

              {/* Description */}
              <p className="mt-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
                {product.description}
              </p>

              {/* Color Selection if Available */}
              {product.options?.cores && product.options.cores.length > 0 && (
                <div className="mt-4">
                  <span className="text-xs font-bold text-slate-300 block mb-1.5">
                    Opção de Cor: <span className="text-white">{selectedColor}</span>
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {product.options.cores.map((cor) => (
                      <button
                        key={cor}
                        onClick={() => setSelectedColor(cor)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          selectedColor === cor
                            ? 'bg-[#1fa64b] border-[#1fa64b] text-white'
                            : 'bg-slate-800/80 border-white/10 text-slate-300 hover:border-white/30'
                        }`}
                      >
                        {cor}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Storage Selection if Available */}
              {product.options?.armazenamento && product.options.armazenamento.length > 0 && (
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-300 block mb-1.5">
                    Armazenamento: <span className="text-white">{selectedStorage}</span>
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {product.options.armazenamento.map((storage) => (
                      <button
                        key={storage}
                        onClick={() => setSelectedStorage(storage)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          selectedStorage === storage
                            ? 'bg-[#1fa64b] border-[#1fa64b] text-white'
                            : 'bg-slate-800/80 border-white/10 text-slate-300 hover:border-white/30'
                        }`}
                      >
                        {storage}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Technical Specs Accordion / Grid */}
              <div className="mt-4 p-3 rounded-xl bg-slate-900/80 border border-white/10 space-y-2">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#1fa64b]" /> Especificações Técnicas:
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {product.specs.tela && (
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Tela:</span>
                      {product.specs.tela}
                    </div>
                  )}
                  {product.specs.bateria && (
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Bateria:</span>
                      {product.specs.bateria}
                    </div>
                  )}
                  {product.specs.camera && (
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Câmeras:</span>
                      {product.specs.camera}
                    </div>
                  )}
                  {product.specs.processador && (
                    <div className="text-slate-300">
                      <span className="text-slate-500 block text-[10px]">Processador:</span>
                      {product.specs.processador}
                    </div>
                  )}
                </div>
              </div>

              {/* In-Store Pickup Info for Itaquiraí */}
              <div className="mt-3 p-3.5 rounded-xl bg-[#0b2c5a]/40 border border-[#1fa64b]/30 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-[#1fa64b]/20 text-[#1fa64b]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">Retirada na Loja Física (Grátis):</span>
                    <span className="text-slate-300 text-[11px]">{STORE_INFO.address}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="px-2.5 py-1 rounded-md bg-[#1fa64b] text-white text-[11px] font-black uppercase">
                    Pronta Entrega
                  </span>
                </div>
              </div>

            </div>

            {/* Actions: Quantity & Purchase Buttons */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex items-center border border-white/20 rounded-xl bg-slate-800 px-2 py-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-2 py-0.5 text-base font-bold text-slate-300 hover:text-white"
                  >
                    -
                  </button>
                  <span className="px-3 font-bold text-white text-sm">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className="px-2 py-0.5 text-base font-bold text-slate-300 hover:text-white"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs text-slate-400">
                  {product.stock} unidades disponíveis no estoque de Itaquiraí
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={() => {
                    onAddToCart(product, quantity, selectedColor, selectedStorage);
                    onClose();
                  }}
                  className="w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#1fa64b] hover:bg-[#23be57] text-white flex items-center justify-center gap-2 shadow-lg shadow-[#1fa64b]/20 transition-all cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Adicionar ao Carrinho</span>
                </button>

                <button
                  onClick={() => {
                    onBuyNow(product, quantity, selectedColor, selectedStorage);
                    onClose();
                  }}
                  className="w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#f4c430] hover:bg-[#fbd354] text-[#0b2c5a] flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <span>Comprar Agora</span>
                </button>
              </div>

              <button
                onClick={handleWhatsApp}
                className="w-full py-2.5 px-4 rounded-xl border border-[#25D366]/40 hover:bg-[#25D366]/10 text-[#25D366] text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Tirar Dúvida sobre este aparelho no WhatsApp Oficial</span>
              </button>

              {/* Admin Quick Action (Only visible when logged into Admin) */}
              {isAdmin && onDeleteProduct && (
                <div className="pt-3 border-t border-rose-500/20 flex flex-col sm:flex-row items-center justify-between gap-2 bg-rose-500/10 p-3 rounded-xl border">
                  <div className="text-left w-full sm:w-auto">
                    <span className="text-[11px] font-bold text-rose-300 block">Painel Administrativo Ativo</span>
                    <span className="text-[10px] text-slate-400">Você tem permissão para remover este produto</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full sm:w-auto px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow active:scale-95"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Excluir Produto</span>
                  </button>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* In-app Deletion Confirmation Dialog */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#121826] p-6 rounded-2xl border border-rose-500/50 max-w-sm w-full space-y-4 shadow-2xl text-center">
              <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-white text-base">Excluir Produto</h4>
              <p className="text-xs text-slate-300">
                Tem certeza que deseja remover <strong>"{product.name}"</strong> definitivamente do catálogo?
              </p>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (onDeleteProduct) {
                      onDeleteProduct(product.id);
                    }
                    setShowDeleteConfirm(false);
                    onClose();
                  }}
                  className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow"
                >
                  Sim, Excluir
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
