import React from 'react';
import { 
  ShieldCheck, 
  Wrench, 
  Sparkles, 
  Truck, 
  CreditCard, 
  ArrowRight, 
  Smartphone,
  CheckCircle2,
  PhoneCall,
  Store
} from 'lucide-react';
import { STORE_INFO } from '../data/mockData';

interface HeroBannerProps {
  onGoToAssistance: () => void;
  onGoToCatalog: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onGoToAssistance,
  onGoToCatalog
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-[#0b2c5a] via-[#081b36] to-[#080d19] py-10 md:py-16 border-b border-white/10">
      {/* Decorative Glow Elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#1fa64b]/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-96 h-96 bg-[#f4c430]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 text-left space-y-5">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#f4c430]" />
              <span>Itaquiraí - MS & Região Cone Sul</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
              Sua Loja de Celulares e{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#1fa64b] via-[#38e370] to-[#f4c430]">
                Assistência Técnica
              </span>{' '}
              Especializada
            </h1>

            <p className="text-slate-300 text-sm sm:text-base max-w-xl leading-relaxed">
              Smartphones <strong>semi-novos</strong> criteriosamente testados e revisados com <strong>90 dias de garantia</strong> legal e assegurada, assistência técnica especializada em telas e baterias, e pagamento seguro via <strong>Pix PagBank automático</strong> ou no balcão.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onGoToAssistance}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#1fa64b] to-[#168a3d] hover:from-[#23be57] hover:to-[#1aa349] text-white font-bold text-sm shadow-lg shadow-[#1fa64b]/30 transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                <Wrench className="w-4 h-4 text-[#f4c430]" />
                <span>Solicitar Orçamento Grátis</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onGoToCatalog}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#121826]/90 hover:bg-[#1a2336] border border-white/20 text-white font-semibold text-sm transition-all cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-[#f4c430]" />
                <span>Ver Seminovos (Garantia 90 Dias)</span>
              </button>

              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/50 text-[#25D366] font-bold text-sm transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>(67) 9 8135-9433</span>
              </a>
            </div>

            {/* Quick Micro Bullet points */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 text-xs text-slate-300 border-t border-white/10">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1fa64b] shrink-0" />
                <span>Troca de telas e baterias</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1fa64b] shrink-0" />
                <span>Retirada no Centro de Itaquiraí</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1fa64b] shrink-0" />
                <span>Consulta de Garantia IMEI</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Trust Card Featuring Official Logo */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="w-full max-w-sm rounded-3xl bg-gradient-to-br from-[#0e2240] to-[#121826] p-6 border border-[#1fa64b]/30 shadow-2xl relative">
              <div className="absolute -top-3 -right-3 bg-[#f4c430] text-[#0b2c5a] text-xs font-black px-3 py-1 rounded-full uppercase shadow">
                Itaquiraí - MS
              </div>

              <div className="flex flex-col items-center text-center space-y-4">
                <div className="relative">
                  <img
                    src={STORE_INFO.logoUrl}
                    alt="Digital Cell Celulares"
                    className="w-28 h-28 rounded-full object-cover border-4 border-[#1fa64b] shadow-xl shadow-[#1fa64b]/30"
                  />
                  <span className="absolute bottom-1 right-1 w-5 h-5 bg-[#1fa64b] border-2 border-[#121826] rounded-full" />
                </div>

                <div>
                  <h3 className="text-xl font-black text-white">DIGITAL CELL CELULARES</h3>
                  <p className="text-xs text-[#1fa64b] font-bold tracking-wider mt-0.5">
                    ASSISTÊNCIA TÉCNICA ESPECIALIZADA
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Celulares • Tablets • Baterias • Acessórios
                  </p>
                </div>

                <div className="w-full space-y-2 pt-2 border-t border-white/10 text-xs">
                  <div className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-white/5">
                    <span className="text-slate-300 flex items-center gap-1.5">
                      <Store className="w-3.5 h-3.5 text-[#38bdf8]" /> Retirada no Local:
                    </span>
                    <span className="font-bold text-[#1fa64b]">Loja Física (Centro) - Grátis</span>
                  </div>

                  <div className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-white/5">
                    <span className="text-slate-300 flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-[#f4c430]" /> PagBank Pix:
                    </span>
                    <span className="font-bold text-white">Aprovação Automática</span>
                  </div>

                  <div className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-white/5">
                    <span className="text-slate-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#1fa64b]" /> Garantia Bancada:
                    </span>
                    <span className="font-bold text-[#f4c430]">90 Dias Registrada</span>
                  </div>
                </div>

                <div className="w-full pt-1">
                  <a
                    href={STORE_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs transition-colors shadow-md"
                  >
                    <span>Falar no WhatsApp: (67) 98135-9433</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
