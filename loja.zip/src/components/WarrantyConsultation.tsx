import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  PhoneCall, 
  Smartphone, 
  FileCheck
} from 'lucide-react';
import { Warranty } from '../types';
import { STORE_INFO } from '../data/mockData';

interface WarrantyConsultationProps {
  warranties: Warranty[];
}

export const WarrantyConsultation: React.FC<WarrantyConsultationProps> = ({ warranties }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searched, setSearched] = useState(false);
  const [foundWarranty, setFoundWarranty] = useState<Warranty | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    const cleanTerm = searchTerm.trim().toLowerCase();

    if (!cleanTerm) {
      setFoundWarranty(null);
      return;
    }

    const match = warranties.find(
      w => w.imeiOrSerial.toLowerCase().includes(cleanTerm) ||
           w.protocol.toLowerCase().includes(cleanTerm) ||
           w.customerPhone.replace(/\D/g, '').includes(cleanTerm.replace(/\D/g, ''))
    );

    setFoundWarranty(match || null);
  };

  const isExpired = (expirationDate: string) => {
    return new Date() > new Date(expirationDate);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Banner */}
      <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-xs font-bold uppercase">
          <ShieldCheck className="w-4 h-4 text-[#f4c430]" />
          <span>Transparência & Segurança Total</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          Consulta de Garantia Digital por IMEI
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Consulte o prazo de garantia, nota de cobertura e laudo do seu aparelho adquirido ou consertado na Digital Cell Celulares em Itaquiraí-MS.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-[#121826] p-5 sm:p-7 rounded-3xl border border-[#1fa64b]/30 shadow-2xl space-y-4">
        <form onSubmit={handleSearch} className="space-y-3">
          <label className="block text-xs font-bold text-slate-300">
            Digite o IMEI (15 dígitos), Número de Série ou Protocolo de Garantia:
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder="Ex: 356892110482910 ou GAR-7741"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-slate-900 border border-white/15 rounded-xl px-4 py-3 text-white text-xs sm:text-sm outline-none focus:border-[#1fa64b]"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-lg shadow-[#1fa64b]/20"
            >
              Consultar Garantia
            </button>
          </div>
        </form>

        {/* Quick Demo IMEI Badges */}
        <div className="pt-3 border-t border-white/10 flex flex-wrap items-center gap-2 text-xs text-slate-400">
          <span className="text-[11px]">Testar com IMEIs registrados:</span>
          <button
            onClick={() => {
              setSearchTerm('356892110482910');
              setSearched(true);
              setFoundWarranty(warranties[0]);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 hover:text-white font-mono text-[11px]"
          >
            356892110482910 (Ativa - 1 Ano)
          </button>
          <button
            onClick={() => {
              setSearchTerm('864290041288341');
              setSearched(true);
              setFoundWarranty(warranties[1]);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 hover:text-white font-mono text-[11px]"
          >
            864290041288341 (Seminovo 6 Meses)
          </button>
        </div>
      </div>

      {/* Result Display */}
      {searched && (
        <div className="mt-6">
          {foundWarranty ? (
            <div className="bg-[#121826] rounded-3xl border border-[#1fa64b]/30 p-6 sm:p-8 shadow-2xl space-y-6">
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-1 rounded-md bg-[#1fa64b]/20 text-[#1fa64b] text-xs font-mono font-bold">
                      {foundWarranty.protocol}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-[#f4c430] text-[#0b2c5a] text-[10px] font-black uppercase">
                      {foundWarranty.condition === 'seminovo' ? 'Seminovo Revisado' : 'Novo Lacrado'}
                    </span>
                  </div>
                  <h3 className="text-xl font-extrabold text-white">
                    {foundWarranty.productName}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    IMEI / Serial: <strong className="text-white">{foundWarranty.imeiOrSerial}</strong>
                  </p>
                </div>

                <div className="text-left sm:text-right">
                  {!isExpired(foundWarranty.expirationDate) ? (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-extrabold">
                      <CheckCircle className="w-4 h-4" />
                      <span>GARANTIA ATIVA</span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 text-xs font-extrabold">
                      <XCircle className="w-4 h-4" />
                      <span>GARANTIA EXPIRADA</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-white/10 space-y-1">
                  <span className="text-slate-400 flex items-center gap-1.5 font-medium">
                    <Calendar className="w-3.5 h-3.5 text-[#38bdf8]" /> Data da Compra:
                  </span>
                  <span className="text-white font-bold text-sm">
                    {new Date(foundWarranty.purchaseDate).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900 border border-white/10 space-y-1">
                  <span className="text-slate-400 flex items-center gap-1.5 font-medium">
                    <Calendar className="w-3.5 h-3.5 text-[#f4c430]" /> Validade da Garantia:
                  </span>
                  <span className="text-[#f4c430] font-bold text-sm">
                    {new Date(foundWarranty.expirationDate).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900 border border-white/10 space-y-1">
                  <span className="text-slate-400 flex items-center gap-1.5 font-medium">
                    <Smartphone className="w-3.5 h-3.5 text-[#1fa64b]" /> Período Coberto:
                  </span>
                  <span className="text-white font-bold text-sm">
                    {foundWarranty.warrantyMonths} Meses de Cobertura
                  </span>
                </div>
              </div>

              {/* Terms of Coverage */}
              <div className="p-4 rounded-2xl bg-[#0b2c5a]/40 border border-[#1fa64b]/30 space-y-2 text-xs">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-[#1fa64b]" /> Termos e Condições de Cobertura:
                </span>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {foundWarranty.terms}
                </p>
                <p className="text-[10px] text-slate-400 pt-1">
                  * Não cobre danos por queda com quebra física de display, contato com líquidos não autorizados ou abertura por assistências terceiras.
                </p>
              </div>

              {/* Action Button */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-xs text-slate-400">
                  Titular: <strong>{foundWarranty.customerName}</strong>
                </span>
                <a
                  href={`https://wa.me/${STORE_INFO.phone}?text=Olá,%20gostaria%20de%20acionar%20a%20garantia%20do%20meu%20aparelho%20${foundWarranty.productName}%20(IMEI:%20${foundWarranty.imeiOrSerial})`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd59] text-white font-bold text-xs flex items-center justify-center gap-2 shadow"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Acionar Suporte de Garantia via WhatsApp</span>
                </a>
              </div>

            </div>
          ) : (
            <div className="p-8 text-center bg-[#121826] rounded-3xl border border-white/10 text-slate-400 space-y-2">
              <AlertCircle className="w-10 h-10 text-rose-400 mx-auto" />
              <h4 className="text-base font-bold text-white">Nenhum registro encontrado</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Não localizamos nenhuma garantia ativa para o termo informado. Verifique se o IMEI de 15 dígitos foi digitado corretamente ou consulte nossa equipe no WhatsApp (67) 98135-9433.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
