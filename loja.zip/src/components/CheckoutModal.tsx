import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckCircle, 
  Copy, 
  QrCode, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Store, 
  CreditCard, 
  Banknote, 
  Check, 
  AlertCircle,
  ExternalLink,
  Printer
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Coupon, Order } from '../types';
import { STORE_INFO } from '../data/mockData';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  coupon: Coupon | null;
  shippingFee: number;
  deliveryType: 'entrega' | 'retirada';
  onOrderPlaced: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  coupon,
  shippingFee,
  deliveryType: initialDeliveryType,
  onOrderPlaced
}) => {
  if (!isOpen) return null;

  // Customer information state
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('(67) 9');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerCpf, setCustomerCpf] = useState('');

  // Delivery option: In-store pickup only
  const deliveryType: 'retirada' = 'retirada';
  const calculatedShipping = 0;

  // Payment options
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'cartao' | 'dinheiro_retirada'>('pix');
  const [trocoPara, setTrocoPara] = useState('');
  const [installments, setInstallments] = useState('1');

  // Order submission & PagBank states
  const [step, setStep] = useState<'dados' | 'pagamento_pix' | 'concluido'>('dados');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);

  // PagBank Pix response state
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [pagBankChargeId, setPagBankChargeId] = useState('');
  const [pixQrCodeUrl, setPixQrCodeUrl] = useState('');
  const [pixCopiaECola, setPixCopiaECola] = useState('');
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutos em segundos

  const subtotal = items.reduce((acc, item) => {
    const unitPrice = item.product.promotionalPrice || item.product.price;
    return acc + unitPrice * item.quantity;
  }, 0);
  
  let discount = 0;
  if (coupon) {
    if (coupon.discountType === 'percentage') {
      discount = (subtotal * coupon.discountValue) / 100;
    } else {
      discount = coupon.discountValue;
    }
  }

  const grandTotal = Math.max(0, subtotal - discount);

  // Timer countdown for PagBank Pix
  useEffect(() => {
    let timer: any;
    if (step === 'pagamento_pix' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, timeLeft]);

  // Polling for PagBank Payment Confirmation
  useEffect(() => {
    let poller: any;
    if (step === 'pagamento_pix' && pagBankChargeId && createdOrder?.paymentStatus !== 'pago') {
      poller = setInterval(async () => {
        try {
          const res = await fetch(`/api/pagbank/status/${pagBankChargeId}`);
          if (res.ok) {
            const data = await res.json();
            if (data.status === 'PAID') {
              clearInterval(poller);
              handlePaymentSuccess();
            }
          }
        } catch (e) {
          // ignore network hiccups in polling
        }
      }, 3000);
    }
    return () => clearInterval(poller);
  }, [step, pagBankChargeId, createdOrder]);

  const handlePaymentSuccess = () => {
    if (createdOrder) {
      const updatedOrder: Order = {
        ...createdOrder,
        paymentStatus: 'pago',
        deliveryStatus: 'em_preparacao'
      };
      setCreatedOrder(updatedOrder);
      onOrderPlaced(updatedOrder);
      setStep('concluido');
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        // confetti fallback
      }
    }
  };

  const handleSimulatePagBankConfirmation = async () => {
    if (!pagBankChargeId) return;
    try {
      setLoading(true);
      const res = await fetch('/api/pagbank/simulate-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chargeId: pagBankChargeId })
      });
      if (res.ok) {
        handlePaymentSuccess();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim() || !customerPhone.trim()) {
      setErrorMsg('Por favor, preencha seu nome e WhatsApp de contato.');
      return;
    }

    setLoading(true);

    const orderId = `PED-${Date.now().toString().slice(-6)}`;
    const newOrder: Order = {
      id: orderId,
      customerName,
      customerPhone,
      customerEmail: customerEmail || 'cliente@digitalcell.com.br',
      customerCpf: customerCpf || '000.000.000-00',
      deliveryType: 'retirada',
      shippingFee: 0,
      items: items.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        price: item.product.promotionalPrice || item.product.price,
        quantity: item.quantity,
        color: item.selectedColor,
        storage: item.selectedStorage,
        image: item.product.images[0]
      })),
      subtotal,
      discount,
      couponCode: coupon?.code,
      total: grandTotal,
      paymentMethod,
      paymentStatus: 'aguardando',
      deliveryStatus: 'aguardando_pagamento',
      createdAt: new Date().toISOString()
    };

    if (paymentMethod === 'pix') {
      try {
        const response = await fetch('/api/pagbank/create-pix', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId,
            amount: grandTotal,
            customerName,
            customerCpf
          })
        });

        if (!response.ok) {
          throw new Error('Falha ao gerar cobrança no PagBank');
        }

        const data = await response.json();
        newOrder.pagbankChargeId = data.chargeId;
        newOrder.pixQrCode = data.qrCodeUrl;
        newOrder.pixCopiaECola = data.copiaECola;
        newOrder.pixExpiresAt = data.expiresAt;

        setPagBankChargeId(data.chargeId);
        setPixQrCodeUrl(data.qrCodeUrl);
        setPixCopiaECola(data.copiaECola);
        setCreatedOrder(newOrder);
        setStep('pagamento_pix');
      } catch (err: any) {
        setErrorMsg('Erro ao conectar com a API do PagBank. Tente novamente.');
      } finally {
        setLoading(false);
      }
    } else {
      // Dinheiro na retirada ou Cartão
      newOrder.paymentStatus = 'aguardando';
      newOrder.deliveryStatus = 'em_preparacao';
      setCreatedOrder(newOrder);
      onOrderPlaced(newOrder);
      setStep('concluido');
      setLoading(false);
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch (e) {}
    }
  };

  const copyToClipboard = () => {
    if (pixCopiaECola) {
      navigator.clipboard.writeText(pixCopiaECola);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 3000);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative w-full max-w-2xl bg-[#121826] text-white rounded-2xl sm:rounded-3xl border border-[#1fa64b]/30 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#0b2c5a] to-[#121826]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#1fa64b]/20 border border-[#1fa64b]/40">
              <ShieldCheck className="w-5 h-5 text-[#1fa64b]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">Finalizar Compra Segura</h3>
              <p className="text-[11px] text-slate-300">Digital Cell Celulares • Itaquiraí - MS</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: Form Details */}
        {step === 'dados' && (
          <form onSubmit={handleSubmitOrder} className="p-4 sm:p-6 space-y-5">
            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Customer Identification */}
            <div>
              <h4 className="text-xs font-bold text-[#1fa64b] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                1. Dados de Identificação
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Nome Completo *</label>
                  <input
                    type="text"
                    required
                    placeholder="Seu nome"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">WhatsApp / Telefone *</label>
                  <input
                    type="text"
                    required
                    placeholder="(67) 98135-9433"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">E-mail (opcional)</label>
                  <input
                    type="email"
                    placeholder="seuemail@exemplo.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">CPF (para nota e Pix PagBank)</label>
                  <input
                    type="text"
                    placeholder="000.000.000-00"
                    value={customerCpf}
                    onChange={(e) => setCustomerCpf(e.target.value)}
                    className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white outline-none focus:border-[#1fa64b]"
                  />
                </div>
              </div>
            </div>

            {/* Pickup Location Info */}
            <div>
              <h4 className="text-xs font-bold text-[#1fa64b] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                2. Local de Retirada (Sem Entrega)
              </h4>
              <div className="p-3.5 rounded-xl bg-slate-900 border border-[#1fa64b]/40 flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#1fa64b]/20 text-[#1fa64b]">
                  <Store className="w-5 h-5" />
                </div>
                <div>
                  <span className="font-bold text-white text-xs block">
                    Retirada na Loja Física Digital Cell:
                  </span>
                  <span className="text-slate-300 text-xs block">{STORE_INFO.address}</span>
                  <span className="text-[11px] text-[#f4c430] font-medium block mt-0.5">
                    Horário: {STORE_INFO.hours} • Sem custo de frete (Grátis)
                  </span>
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <h4 className="text-xs font-bold text-[#1fa64b] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                3. Forma de Pagamento
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('pix')}
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                    paymentMethod === 'pix'
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-[#1fa64b]'
                      : 'bg-slate-900 border-white/10 text-slate-300'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-[#1fa64b]" />
                  <div className="text-left">
                    <span className="block font-bold">Pix PagBank</span>
                    <span className="text-[10px] text-[#f4c430]">Liberação Instantânea</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('cartao')}
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                    paymentMethod === 'cartao'
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-[#1fa64b]'
                      : 'bg-slate-900 border-white/10 text-slate-300'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-[#38bdf8]" />
                  <div className="text-left">
                    <span className="block font-bold">Cartão de Crédito</span>
                    <span className="text-[10px] text-slate-400">Até 12x</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('dinheiro_retirada')}
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                    paymentMethod === 'dinheiro_retirada'
                      ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-[#1fa64b]'
                      : 'bg-slate-900 border-white/10 text-slate-300'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-[#f4c430]" />
                  <div className="text-left">
                    <span className="block font-bold">Pagar na Entrega</span>
                    <span className="text-[10px] text-slate-400">Dinheiro ou Cartão</span>
                  </div>
                </button>
              </div>

              {paymentMethod === 'cartao' && (
                <div className="mt-3 p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2 text-xs">
                  <label className="block text-slate-400">Selecione o parcelamento:</label>
                  <select
                    value={installments}
                    onChange={(e) => setInstallments(e.target.value)}
                    className="w-full bg-slate-950 border border-white/20 rounded-lg p-2 text-white outline-none"
                  >
                    <option value="1">1x de R$ {grandTotal.toFixed(2)} (Sem juros)</option>
                    <option value="2">2x de R$ {(grandTotal / 2).toFixed(2)} (Sem juros)</option>
                    <option value="3">3x de R$ {(grandTotal / 3).toFixed(2)} (Sem juros)</option>
                    <option value="6">6x de R$ {((grandTotal * 1.05) / 6).toFixed(2)}</option>
                    <option value="10">10x de R$ {((grandTotal * 1.08) / 10).toFixed(2)}</option>
                    <option value="12">12x de R$ {((grandTotal * 1.10) / 12).toFixed(2)}</option>
                  </select>
                </div>
              )}

              {paymentMethod === 'dinheiro_retirada' && (
                <div className="mt-3 p-3 rounded-xl bg-slate-900 border border-white/10 text-xs">
                  <label className="block text-slate-400 mb-1">Precisa de troco para quanto?</label>
                  <input
                    type="text"
                    placeholder="Ex: R$ 100,00 ou não preciso de troco"
                    value={trocoPara}
                    onChange={(e) => setTrocoPara(e.target.value)}
                    className="w-full bg-slate-950 border border-white/15 rounded-lg px-2.5 py-1.5 text-white outline-none"
                  />
                </div>
              )}
            </div>

            {/* Summary & Submit */}
            <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs text-slate-400 block">Total do Pedido:</span>
                <span className="text-xl font-black text-[#f4c430]">
                  R$ {grandTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-8 py-3 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-sm shadow-lg shadow-[#1fa64b]/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {loading ? 'Processando com PagBank...' : 'Confirmar e Ir para Pagamento'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: PagBank Pix Screen */}
        {step === 'pagamento_pix' && (
          <div className="p-4 sm:p-6 space-y-5 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-xs font-bold">
              <QrCode className="w-4 h-4" />
              <span>Cobrança Pix Oficial PagBank Gerada</span>
            </div>

            <h4 className="text-lg font-black text-white">Escaneie o QR Code ou Copie o Código Pix</h4>
            
            <div className="flex items-center justify-center gap-2 text-xs text-slate-300">
              <Clock className="w-4 h-4 text-[#f4c430]" />
              <span>Esta cobrança vence em: <strong className="text-[#f4c430]">{formatTime(timeLeft)}</strong></span>
            </div>

            {/* QR Code Canvas/Image */}
            <div className="w-60 h-60 mx-auto bg-white p-3 rounded-2xl shadow-xl flex items-center justify-center border-4 border-[#0b2c5a]">
              {pixQrCodeUrl ? (
                <img src={pixQrCodeUrl} alt="QR Code PagBank Pix" className="w-full h-full object-contain" />
              ) : (
                <div className="text-slate-600 text-xs">Carregando QR Code...</div>
              )}
            </div>

            {/* Total Display */}
            <div className="text-2xl font-black text-[#1fa64b]">
              R$ {grandTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>

            {/* Copia e Cola Box */}
            <div className="max-w-md mx-auto space-y-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={pixCopiaECola}
                  className="w-full bg-slate-900 border border-white/20 rounded-xl px-3 py-2 text-xs font-mono text-slate-300 select-all outline-none"
                />
                <button
                  onClick={copyToClipboard}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    copiedCode 
                      ? 'bg-[#1fa64b] text-white' 
                      : 'bg-[#f4c430] hover:bg-[#ffcf3d] text-[#0b2c5a]'
                  }`}
                >
                  {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedCode ? 'Copiado!' : 'Copiar'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                Abra o app do seu banco, escolha Pix &gt; Pix Copia e Cola, e conclua o pagamento.
              </p>
            </div>

            {/* PagBank Integration Simulation & Status Polling notice */}
            <div className="p-4 rounded-2xl bg-[#0b2c5a]/40 border border-[#1fa64b]/30 max-w-md mx-auto space-y-2.5 text-xs text-left">
              <div className="flex items-center gap-2 text-[#1fa64b] font-bold">
                <span className="w-2 h-2 rounded-full bg-[#1fa64b] animate-ping" />
                <span>Aguardando webhook do PagBank (atualização em tempo real)...</span>
              </div>
              <p className="text-slate-300 text-[11px]">
                O sistema consulta a API PagBank automaticamente a cada 3 segundos. Assim que o pagamento for registrado, o status mudará sozinho para aprovado.
              </p>
              
              {/* Simulation button for demo testing */}
              <button
                type="button"
                onClick={handleSimulatePagBankConfirmation}
                disabled={loading}
                className="w-full py-2 px-3 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 text-emerald-200 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Simular Aprovação PagBank (Ambiente de Teste)</span>
              </button>
            </div>

          </div>
        )}

        {/* STEP 3: Order Completed & Receipt */}
        {step === 'concluido' && createdOrder && (
          <div className="p-5 sm:p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#1fa64b]/20 border-2 border-[#1fa64b] flex items-center justify-center mx-auto text-[#1fa64b]">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-white">
              Pedido Realizado com Sucesso!
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
              Seu pedido <strong>#{createdOrder.id}</strong> foi registrado na Digital Cell Celulares em Itaquiraí-MS.
            </p>

            {/* Receipt Summary Card */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 text-left text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between border-b border-white/10 pb-1.5 font-bold">
                <span className="text-slate-300">Protocolo do Pedido:</span>
                <span className="text-[#f4c430]">{createdOrder.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Cliente:</span>
                <span className="text-white font-medium">{createdOrder.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">WhatsApp:</span>
                <span className="text-white font-medium">{createdOrder.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Modalidade:</span>
                <span className="text-white font-medium">
                  Retirada na Loja física ({STORE_INFO.address})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status do Pagamento:</span>
                <span className="text-[#1fa64b] font-bold uppercase">
                  {createdOrder.paymentStatus === 'pago' ? 'Confirmado pelo PagBank' : 'Aguardando Pagamento'}
                </span>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-1.5 font-extrabold text-sm">
                <span className="text-white">Valor Total:</span>
                <span className="text-[#f4c430]">
                  R$ {createdOrder.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5 justify-center max-w-md mx-auto">
              <button
                onClick={() => {
                  const msg = encodeURIComponent(
                    `Olá Digital Cell! Acabei de fazer o pedido *#${createdOrder.id}* no site da loja em Itaquiraí no valor de R$ ${createdOrder.total.toFixed(2)}. Gostaria de acompanhar a separação!`
                  );
                  window.open(`https://wa.me/${STORE_INFO.phone}?text=${msg}`, '_blank');
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd59] text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Notificar Loja pelo WhatsApp</span>
              </button>

              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Concluir e Voltar à Loja
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
