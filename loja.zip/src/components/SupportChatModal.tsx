import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  PhoneCall, 
  HelpCircle,
  MessageSquare
} from 'lucide-react';
import { STORE_INFO } from '../data/mockData';

interface SupportChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  role: 'bot' | 'user';
  text: string;
  time: string;
}

export const SupportChatModal: React.FC<SupportChatModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'bot',
      text: 'Olá! Sou o assistente virtual da Digital Cell Celulares em Itaquiraí-MS. Como posso ajudar você hoje? Você pode tirar dúvidas sobre consertos, preços, garantias ou falar direto com nossos técnicos.',
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickChips = [
    'Onde fica a loja em Itaquiraí?',
    'Quanto custa trocar a tela?',
    'Como funciona a garantia dos seminovos?',
    'Vocês aceitam Pix e parcelam no cartão?'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (userText: string) => {
    const textToSend = userText || input;
    if (!textToSend.trim() || loading) return;

    const newMsg: ChatMessage = {
      role: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, newMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: messages.map(m => ({ role: m.role === 'bot' ? 'model' : 'user', text: m.text }))
        })
      });

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          role: 'bot',
          text: data.reply || 'Desculpe, não consegui entender. Gostaria de falar com nossa equipe no WhatsApp?',
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'bot',
          text: 'Tive um problema na conexão, mas você pode falar instantaneamente conosco pelo WhatsApp oficial no (67) 98135-9433!',
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm flex justify-center sm:justify-end items-end sm:items-center p-0 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-md h-[90vh] sm:h-[620px] bg-[#121826] text-white rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col border border-[#1fa64b]/30 overflow-hidden animate-in slide-in-from-bottom sm:slide-in-from-right duration-250"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#0b2c5a] to-[#121826] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={STORE_INFO.logoUrl} 
                alt="Digital Cell" 
                className="w-10 h-10 rounded-full object-cover border-2 border-[#1fa64b]" 
              />
              <span className="w-3 h-3 bg-[#1fa64b] border-2 border-[#121826] rounded-full absolute -bottom-0.5 -right-0.5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-[#1fa64b]" />
                <h3 className="font-bold text-sm text-white">Assistente Robô Digital Cell</h3>
                <span className="bg-[#1fa64b]/20 text-[#1fa64b] text-[10px] font-black px-1.5 py-0.2 rounded">
                  Online
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                Assistente Inteligente • Itaquiraí-MS
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Human Handover Bar */}
        <div className="bg-[#0b2c5a]/50 px-4 py-2 border-b border-white/10 flex items-center justify-between text-xs">
          <span className="text-slate-300 text-[11px]">Dúvida complexa ou negociação?</span>
          <a
            href={STORE_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#25D366] hover:bg-[#20bd59] text-white font-bold text-[11px] shadow transition-colors"
          >
            <PhoneCall className="w-3 h-3" />
            <span>Falar no WhatsApp</span>
          </a>
        </div>

        {/* Message Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'bot' && (
                <div className="w-7 h-7 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 flex items-center justify-center text-[#1fa64b] shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] rounded-2xl p-3 text-xs leading-relaxed space-y-1 ${
                  m.role === 'user'
                    ? 'bg-[#1fa64b] text-white rounded-tr-none'
                    : 'bg-slate-900 border border-white/10 text-slate-200 rounded-tl-none'
                }`}
              >
                <p className="whitespace-pre-line">{m.text}</p>
                <span className={`block text-[9px] text-right ${m.role === 'user' ? 'text-white/70' : 'text-slate-500'}`}>
                  {m.time}
                </span>
              </div>

              {m.role === 'user' && (
                <div className="w-7 h-7 rounded-full bg-slate-800 border border-white/20 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-2 items-center text-slate-400 text-xs pl-9">
              <span className="w-2 h-2 rounded-full bg-[#1fa64b] animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-[#1fa64b] animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-[#1fa64b] animate-bounce [animation-delay:0.4s]" />
              <span className="text-[11px] text-slate-400 ml-1">Digitando resposta...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Question Chips */}
        <div className="px-4 py-2 border-t border-white/10 bg-slate-900/60 overflow-x-auto flex gap-1.5 no-scrollbar">
          {quickChips.map((chip, i) => (
            <button
              key={i}
              onClick={() => handleSend(chip)}
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800 hover:bg-[#1fa64b]/20 hover:border-[#1fa64b] border border-white/10 text-[11px] text-slate-300 transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-white/10 bg-[#080d19]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(input);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Digite sua dúvida ou pergunta..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-slate-900 border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs outline-none focus:border-[#1fa64b]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white disabled:opacity-50 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
