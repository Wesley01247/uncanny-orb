import React from 'react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  CreditCard, 
  QrCode, 
  Wrench, 
  Store
} from 'lucide-react';
import { STORE_INFO } from '../data/mockData';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#071324] text-slate-300 border-t border-white/10 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-white/10">
          
          {/* Col 1: Store & Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={STORE_INFO.logoUrl}
                alt="Digital Cell Celulares"
                className="w-12 h-12 rounded-full object-cover border-2 border-[#1fa64b]"
              />
              <div>
                <span className="font-black text-lg text-white block">
                  DIGITAL<span className="text-[#f4c430]">CELL</span>
                </span>
                <span className="text-[11px] text-[#1fa64b] font-bold uppercase tracking-wider block">
                  Itaquiraí - MS
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Referência em assistência técnica especializada e venda de smartphones semi-novos criteriosamente revisados com garantia de 90 dias em Itaquiraí e região Cone Sul de Mato Grosso do Sul.
            </p>

            <div className="pt-1">
              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 text-[#25D366] text-xs font-bold hover:bg-[#25D366]/30 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp: {STORE_INFO.phoneFormatted}</span>
              </a>
            </div>
          </div>

          {/* Col 2: Services & Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Navegação & Serviços
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('catalogo')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  • Catálogo de Seminovos e Acessórios
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('assistencia')}
                  className="hover:text-white transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <Wrench className="w-3 h-3 text-[#1fa64b]" />
                  <span>Orçamento de Assistência Técnica (OS)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('garantias')}
                  className="hover:text-white transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3 h-3 text-[#1fa64b]" />
                  <span>Consulta de Garantia 90 Dias (IMEI)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('pedidos')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  • Acompanhar Retirada de Pedido
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Physical Store in Itaquiraí */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Loja Física Itaquiraí
            </h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#1fa64b] shrink-0 mt-0.5" />
                <span className="text-white font-medium">
                  {STORE_INFO.address}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-[#f4c430] shrink-0 mt-0.5" />
                <span>
                  {STORE_INFO.hours}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <Store className="w-4 h-4 text-[#38bdf8] shrink-0 mt-0.5" />
                <span>Atendimento presencial e balcão técnico</span>
              </div>
            </div>
          </div>

          {/* Col 4: Payments & Security */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Pagamento & Segurança
            </h4>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-900 border border-white/10 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-[#1fa64b]" />
                <div>
                  <span className="font-bold text-white block">Pix PagBank</span>
                  <span className="text-[10px] text-slate-400">QR Code e confirmação automática</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900 border border-white/10 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#38bdf8]" />
                <div>
                  <span className="font-bold text-white block">Cartões de Crédito</span>
                  <span className="text-[10px] text-slate-400">Parcelamento em até 12x</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900 border border-white/10 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#f4c430]" />
                <div>
                  <span className="font-bold text-white block">Garantia 90 Dias</span>
                  <span className="text-[10px] text-slate-400">Termo assinado e consulta online</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Credits */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Digital Cell Celulares - Itaquiraí, MS. Todos os direitos reservados.</p>
          <div className="flex items-center gap-1">
            <span>Rua Campo Grande, 1161 - Centro • WhatsApp: (67) 98135-9433</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
