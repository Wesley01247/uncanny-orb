import React, { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Package, 
  Wrench, 
  ShieldCheck, 
  AlertTriangle, 
  ShoppingBag, 
  Plus, 
  Edit3, 
  Trash2, 
  Download, 
  Printer, 
  CheckCircle, 
  Clock, 
  Store, 
  Key,
  Layers,
  Settings,
  CreditCard,
  LogOut,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowLeft,
  Check,
  Search,
  Terminal,
  Copy
} from 'lucide-react';
import { Product, Order, TechnicalAssistanceOS, Warranty, OSStatus, DeliveryStatus } from '../types';
import { STORE_INFO } from '../data/mockData';

interface AdminPanelProps {
  products: Product[];
  orders: Order[];
  osList: TechnicalAssistanceOS[];
  warranties: Warranty[];
  onUpdateOrderStatus: (orderId: string, deliveryStatus: DeliveryStatus, paymentStatus?: any) => void;
  onUpdateOS: (protocol: string, status: OSStatus, partsCost: number, laborCost: number, notes: string) => void;
  onAddProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onUpdateStock: (productId: string, newStock: number) => void;
  onAddWarranty: (warranty: Warranty) => void;
  onBackToStore?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  products,
  orders,
  osList,
  warranties,
  onUpdateOrderStatus,
  onUpdateOS,
  onAddProduct,
  onDeleteProduct,
  onUpdateStock,
  onAddWarranty,
  onBackToStore
}) => {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('digitalcell_admin_auth') === 'true';
  });

  // Login Form States (starts completely empty, only shows when typed)
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Active Admin Tab
  const [activeTab, setActiveTab] = useState<'financeiro' | 'os' | 'pedidos' | 'produtos' | 'garantias' | 'config'>('financeiro');
  
  // Product Creation state
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<Product['category']>('Smartphones');
  const [newProdBrand, setNewProdBrand] = useState<Product['brand']>('Apple');
  const [newProdCondition, setNewProdCondition] = useState<'novo' | 'seminovo'>('seminovo');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdCost, setNewProdCost] = useState('');
  const [newProdStock, setNewProdStock] = useState('5');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdImg, setNewProdImg] = useState('https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=800&q=80');

  // Product Deletion & Search states
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [productSearch, setProductSearch] = useState('');
  const [feedbackToast, setFeedbackToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [copiedTermux, setCopiedTermux] = useState(false);

  // OS edit state
  const [editingOS, setEditingOS] = useState<TechnicalAssistanceOS | null>(null);
  const [osPartsCost, setOsPartsCost] = useState(0);
  const [osLaborCost, setOsLaborCost] = useState(0);
  const [osStatus, setOsStatus] = useState<OSStatus>('recebido');
  const [osNotes, setOsNotes] = useState('');

  // New Warranty state
  const [showAddWarranty, setShowAddWarranty] = useState(false);
  const [warImei, setWarImei] = useState('');
  const [warProduct, setWarProduct] = useState('');
  const [warCustomer, setWarCustomer] = useState('');
  const [warPhone, setWarPhone] = useState('(67) 9');
  const [warMonths, setWarMonths] = useState(12);

  // Authentication Handlers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const cleanEmail = loginEmail.trim().toLowerCase();
    const cleanPass = loginPassword.trim();

    // Default administrative credentials
    if ((cleanEmail === 'admin@digitalcell.com.br' || cleanEmail === 'admin') && 
        (cleanPass === 'admin123' || cleanPass === '123456' || cleanPass === 'admin')) {
      sessionStorage.setItem('digitalcell_admin_auth', 'true');
      setIsAuthenticated(true);
    } else {
      setLoginError('Credenciais incorretas. Usuário ou senha inválidos.');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('digitalcell_admin_auth');
    setIsAuthenticated(false);
    setLoginPassword('');
  };

  // Financial Calculations
  const paidOrders = orders.filter(o => o.paymentStatus === 'pago');
  const totalRevenue = paidOrders.reduce((acc, o) => acc + o.total, 0);

  const totalCost = paidOrders.reduce((acc, o) => {
    return acc + o.items.reduce((itemAcc, item) => {
      const prod = products.find(p => p.id === item.productId);
      return itemAcc + ((prod?.costPrice || item.price * 0.7) * item.quantity);
    }, 0);
  }, 0);

  const grossProfit = Math.max(0, totalRevenue - totalCost);
  const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const activeOS = osList.filter(o => o.status !== 'entregue' && o.status !== 'recusado');
  const lowStockProducts = products.filter(p => p.stock <= 4);

  const handleExportCSV = () => {
    let csv = 'ID Pedido,Cliente,WhatsApp,Forma Pagamento,Total,Status Pagamento,Status Retirada,Data\n';
    orders.forEach(o => {
      csv += `"${o.id}","${o.customerName}","${o.customerPhone}","${o.paymentMethod}","${o.total.toFixed(2)}","${o.paymentStatus}","${o.deliveryStatus}","${new Date(o.createdAt).toLocaleDateString('pt-BR')}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `relatorio_digitalcell_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName || !newProdPrice || !newProdCost) return;

    const prod: Product = {
      id: `prod-${Date.now()}`,
      name: newProdName,
      category: newProdCategory,
      brand: newProdBrand,
      condition: newProdCondition,
      description: newProdDesc || 'Aparelho semi-novo rigorosamente revisado e testado, com 90 dias de garantia pela Digital Cell Itaquiraí.',
      specs: {},
      price: parseFloat(newProdPrice),
      costPrice: parseFloat(newProdCost),
      stock: parseInt(newProdStock) || 1,
      images: [newProdImg],
      warrantyMonths: 3, // 90 dias
      rating: 5,
      reviewsCount: 1
    };

    onAddProduct(prod);
    setShowAddProduct(false);
    setNewProdName('');
    setNewProdPrice('');
    setNewProdCost('');
  };

  const handleSaveWarranty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!warImei || !warProduct || !warCustomer) return;

    const now = new Date();
    const expDate = new Date();
    expDate.setMonth(expDate.getMonth() + warMonths);

    const newWar: Warranty = {
      id: `war-${Date.now()}`,
      protocol: `GAR-${Math.floor(1000 + Math.random() * 9000)}`,
      imeiOrSerial: warImei.trim(),
      productName: warProduct.trim(),
      customerName: warCustomer.trim(),
      customerPhone: warPhone.trim(),
      purchaseDate: now.toISOString().split('T')[0],
      expirationDate: expDate.toISOString().split('T')[0],
      warrantyMonths: warMonths,
      condition: 'seminovo',
      status: 'ativa',
      terms: `Garantia legal de 90 dias assegurada pela Digital Cell Celulares em Itaquiraí-MS para componentes e fabricação.`
    };

    onAddWarranty(newWar);
    setShowAddWarranty(false);
    setWarImei('');
    setWarProduct('');
    setWarCustomer('');
  };

  // -------------------------------------------------------------
  // TELA 1: LOGIN ADMINISTRATIVO SEPARADO (Se não estiver autenticado)
  // -------------------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="min-h-[85vh] flex items-center justify-center p-4 sm:p-6 bg-gradient-to-b from-[#080d19] via-[#0b2c5a]/40 to-[#080d19]">
        <div className="w-full max-w-md bg-[#121826] rounded-3xl border border-[#1fa64b]/40 shadow-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
          
          {/* Subtle Background Glows */}
          <div className="absolute -top-16 -right-16 w-40 h-40 bg-[#1fa64b]/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-40 h-40 bg-[#f4c430]/15 rounded-full blur-3xl pointer-events-none" />

          {/* Header Brand */}
          <div className="flex flex-col items-center text-center space-y-3">
            <div className="relative">
              <img
                src={STORE_INFO.logoUrl}
                alt="Digital Cell Celulares"
                className="w-20 h-20 rounded-full object-cover border-4 border-[#1fa64b] shadow-xl shadow-[#1fa64b]/30"
              />
              <span className="absolute -bottom-1 -right-1 p-1 bg-[#1fa64b] rounded-full text-white">
                <Lock className="w-3.5 h-3.5" />
              </span>
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-[11px] font-bold uppercase mb-1">
                <span>Área Restrita da Gerência</span>
              </div>
              <h2 className="text-xl font-extrabold text-white">
                Painel Administrativo
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Digital Cell Celulares • Itaquiraí - MS
              </p>
            </div>
          </div>

          {/* Error Message */}
          {loginError && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1.5">
                E-mail ou Usuário do Gerente:
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="Digite seu e-mail ou usuário"
                  className="w-full bg-slate-900 border border-white/15 rounded-xl pl-9 pr-3 py-2.5 text-white outline-none focus:border-[#1fa64b]"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1.5">
                Senha Administrativa:
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Digite a senha..."
                  className="w-full bg-slate-900 border border-white/15 rounded-xl pl-9 pr-10 py-2.5 text-white outline-none focus:border-[#1fa64b]"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs sm:text-sm shadow-lg shadow-[#1fa64b]/30 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Key className="w-4 h-4" />
              <span>Acessar Painel ADM</span>
            </button>
          </form>

          {/* Quick Access Helper */}
          <div className="pt-2 border-t border-white/10 space-y-2.5 text-center">
            {onBackToStore && (
              <button
                type="button"
                onClick={onBackToStore}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Voltar à Loja Virtual</span>
              </button>
            )}
          </div>

        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // TELA 2: PAINEL ADMINISTRATIVO AUTENTICADO (100% Retirada na Loja)
  // -------------------------------------------------------------
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Admin Top Header with Session Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 bg-[#121826] p-6 rounded-3xl border border-[#1fa64b]/30 shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b]">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#f4c430] uppercase tracking-wider">
                Sessão Ativa: Gerente / Proprietário
              </span>
              <span className="bg-[#1fa64b] text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                Loja Física Itaquiraí - MS
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Painel Operacional & Financeiro
            </h2>
          </div>
        </div>

        {/* Top Session Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          {onBackToStore && (
            <button
              onClick={onBackToStore}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/10 text-slate-200 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Ver Loja Virtual</span>
            </button>
          )}

          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/10 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>Exportar CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/10 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-[#f4c430]" />
            <span>Imprimir</span>
          </button>

          <button
            onClick={handleLogout}
            className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Encerrar Sessão Administrativa"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sair</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 border-b border-white/10 no-scrollbar">
        <button
          onClick={() => setActiveTab('financeiro')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'financeiro' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Financeiro & Métricas</span>
        </button>

        <button
          onClick={() => setActiveTab('pedidos')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'pedidos' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Pedidos Retirada ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('os')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'os' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>Assistência OS ({osList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('produtos')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'produtos' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Produtos & Estoque ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('garantias')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'garantias' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Garantias & IMEI ({warranties.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('config')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'config' ? 'bg-[#1fa64b] text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>PagBank & Loja</span>
        </button>
      </div>

      {/* TAB 1: Financeiro & Métricas */}
      {activeTab === 'financeiro' && (
        <div className="space-y-6">
          {/* Metric KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#121826] p-5 rounded-2xl border border-white/10 shadow-lg">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-[#1fa64b]" /> Faturamento Confirmado
              </span>
              <div className="text-2xl font-black text-white mt-1">
                R$ {totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[11px] text-[#1fa64b] font-semibold mt-1 block">
                {paidOrders.length} pedido(s) pagos
              </span>
            </div>

            <div className="bg-[#121826] p-5 rounded-2xl border border-white/10 shadow-lg">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-slate-400" /> Custo Mercadorias (CMV)
              </span>
              <div className="text-2xl font-black text-slate-300 mt-1">
                R$ {totalCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[11px] text-slate-500 font-medium mt-1 block">
                Custo de aquisição de aparelhos
              </span>
            </div>

            <div className="bg-[#121826] p-5 rounded-2xl border border-[#1fa64b]/40 shadow-lg">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-[#f4c430]" /> Lucro Bruto Estimado
              </span>
              <div className="text-2xl font-black text-[#f4c430] mt-1">
                R$ {grossProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[11px] text-[#1fa64b] font-semibold mt-1 block">
                Margem de Lucro: {profitMargin.toFixed(1)}%
              </span>
            </div>

            <div className="bg-[#121826] p-5 rounded-2xl border border-white/10 shadow-lg">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-[#38bdf8]" /> OS em Andamento
              </span>
              <div className="text-2xl font-black text-white mt-1">
                {activeOS.length}
              </div>
              <span className="text-[11px] text-[#38bdf8] font-semibold mt-1 block">
                Ordens de serviço ativas na bancada
              </span>
            </div>
          </div>

          {/* Low Stock Warning Banner */}
          {lowStockProducts.length > 0 && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-amber-300">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span>
                  <strong>Atenção ao Estoque:</strong> {lowStockProducts.length} produto(s) com menos de 4 unidades disponíveis na loja de Itaquiraí.
                </span>
              </div>
              <button
                onClick={() => setActiveTab('produtos')}
                className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors cursor-pointer"
              >
                Ver Estoque
              </button>
            </div>
          )}

          {/* Operational Policy Cards (100% Retirada na Loja) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#121826] p-5 rounded-2xl border border-white/10 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#1fa64b]" />
                <span>Vendas por Forma de Pagamento</span>
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2 rounded-lg bg-slate-900">
                  <span className="text-slate-300 font-medium">Pix PagBank Automático:</span>
                  <span className="font-bold text-[#1fa64b]">
                    {orders.filter(o => o.paymentMethod === 'pix').length} pedido(s)
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded-lg bg-slate-900">
                  <span className="text-slate-300 font-medium">Cartão de Crédito:</span>
                  <span className="font-bold text-[#38bdf8]">
                    {orders.filter(o => o.paymentMethod === 'cartao').length} pedido(s)
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded-lg bg-slate-900">
                  <span className="text-slate-300 font-medium">Dinheiro / Retirada:</span>
                  <span className="font-bold text-[#f4c430]">
                    {orders.filter(o => o.paymentMethod === 'dinheiro_retirada').length} pedido(s)
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-[#121826] p-5 rounded-2xl border border-white/10 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Store className="w-4 h-4 text-[#38bdf8]" />
                <span>Política Operacional de Retirada</span>
              </h3>
              <div className="p-3 rounded-xl bg-slate-900 border border-[#1fa64b]/30 space-y-1.5 text-xs">
                <span className="text-slate-300 font-bold block text-white">
                  100% Retirada na Loja Física (Sem Entrega Externa)
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Os clientes compram pelo site e retiram diretamente no balcão da loja física na <strong>Av. Mato Grosso, 850 - Centro</strong>, garantindo custo zero de frete e inspeção imediata do aparelho.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Pedidos para Retirada */}
      {activeTab === 'pedidos' && (
        <div className="bg-[#121826] rounded-3xl border border-white/10 p-5 sm:p-7 shadow-2xl overflow-x-auto">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-base font-bold text-white">Pedidos para Retirada na Loja</h3>
              <p className="text-xs text-slate-400">Gerencie a separação de estoque e liberação no balcão.</p>
            </div>
          </div>

          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Código</th>
                <th className="p-3">Cliente</th>
                <th className="p-3">WhatsApp</th>
                <th className="p-3">Itens</th>
                <th className="p-3">Total</th>
                <th className="p-3">Pagamento</th>
                <th className="p-3">Situação Retirada</th>
                <th className="p-3">Atualizar Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {orders.map((o) => (
                <tr key={o.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="p-3 font-mono font-bold text-[#f4c430]">#{o.id}</td>
                  <td className="p-3 font-medium text-white">{o.customerName}</td>
                  <td className="p-3">{o.customerPhone}</td>
                  <td className="p-3">{o.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}</td>
                  <td className="p-3 font-bold text-white">R$ {o.total.toFixed(2)}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      o.paymentStatus === 'pago' ? 'bg-[#1fa64b]/20 text-[#1fa64b]' : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {o.paymentStatus}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-800 text-slate-300">
                      {o.deliveryStatus === 'pronto_retirada' ? 'Pronto p/ Retirada' : 
                       o.deliveryStatus === 'retirado' ? 'Retirado' :
                       o.deliveryStatus === 'em_separacao' ? 'Em Separação' :
                       o.deliveryStatus.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="p-3">
                    <select
                      value={o.deliveryStatus}
                      onChange={(e) => onUpdateOrderStatus(o.id, e.target.value as DeliveryStatus)}
                      className="bg-slate-900 border border-white/20 rounded-lg p-1 text-[11px] text-white outline-none"
                    >
                      <option value="aguardando_pagamento">Aguardando Pagamento</option>
                      <option value="pago">Pago</option>
                      <option value="em_separacao">Em Separação</option>
                      <option value="pronto_retirada">Pronto para Retirada</option>
                      <option value="retirado">Retirado pelo Cliente</option>
                      <option value="cancelado">Cancelado</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3: Assistência Técnica OS */}
      {activeTab === 'os' && (
        <div className="bg-[#121826] rounded-3xl border border-white/10 p-5 sm:p-7 shadow-2xl overflow-x-auto space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-white">Ordens de Serviço em Bancada</h3>
          </div>

          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Protocolo</th>
                <th className="p-3">Aparelho</th>
                <th className="p-3">Cliente</th>
                <th className="p-3">Defeito</th>
                <th className="p-3">Peças</th>
                <th className="p-3">Mão de Obra</th>
                <th className="p-3">Total</th>
                <th className="p-3">Status</th>
                <th className="p-3">Editar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {osList.map((os) => (
                <tr key={os.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="p-3 font-mono font-bold text-[#f4c430]">{os.protocol}</td>
                  <td className="p-3 font-semibold text-white">{os.brand} {os.model}</td>
                  <td className="p-3">{os.customerName} ({os.customerPhone})</td>
                  <td className="p-3 max-w-xs truncate">{os.defectDescription}</td>
                  <td className="p-3">R$ {os.partsCost.toFixed(2)}</td>
                  <td className="p-3">R$ {os.laborCost.toFixed(2)}</td>
                  <td className="p-3 font-bold text-[#1fa64b]">R$ {os.totalCost.toFixed(2)}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-[#1fa64b]/20 text-[#1fa64b]">
                      {os.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => {
                        setEditingOS(os);
                        setOsStatus(os.status);
                        setOsPartsCost(os.partsCost);
                        setOsLaborCost(os.laborCost);
                        setOsNotes(os.technicianNotes || '');
                      }}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-[#1fa64b] text-white transition-colors cursor-pointer"
                      title="Editar Orçamento e Status"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* OS Edit Modal */}
          {editingOS && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#121826] p-6 rounded-3xl border border-[#1fa64b]/40 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-white text-base">
                    Editar OS {editingOS.protocol} ({editingOS.model})
                  </h4>
                  <button onClick={() => setEditingOS(null)} className="text-slate-400 hover:text-white">✕</button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 mb-1">Status da OS:</label>
                    <select
                      value={osStatus}
                      onChange={(e: any) => setOsStatus(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                    >
                      <option value="recebido">Recebido na Loja</option>
                      <option value="analise_tecnica">Análise Técnica e Laudo</option>
                      <option value="orcamento_pronto">Orçamento Pronto</option>
                      <option value="aguardando_aprovacao">Aguardando Aprovação do Cliente</option>
                      <option value="em_reparo">Em Reparo na Bancada</option>
                      <option value="testes_finais">Testes Finais de Qualidade</option>
                      <option value="pronto_retirada">Pronto para Retirada</option>
                      <option value="entregue">Entregue ao Cliente</option>
                      <option value="recusado">Recusado</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-300 mb-1">Custo de Peças (R$):</label>
                      <input
                        type="number"
                        value={osPartsCost}
                        onChange={(e) => setOsPartsCost(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Mão de Obra (R$):</label>
                      <input
                        type="number"
                        value={osLaborCost}
                        onChange={(e) => setOsLaborCost(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1">Laudo / Notas do Técnico:</label>
                    <textarea
                      rows={3}
                      value={osNotes}
                      onChange={(e) => setOsNotes(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => setEditingOS(null)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      onUpdateOS(editingOS.protocol, osStatus, osPartsCost, osLaborCost, osNotes);
                      setEditingOS(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs font-bold"
                  >
                    Salvar Alterações
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: Produtos & Estoque */}
      {activeTab === 'produtos' && (
        <div className="bg-[#121826] rounded-3xl border border-white/10 p-5 sm:p-7 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Package className="w-5 h-5 text-[#1fa64b]" />
                <span>Catálogo de Produtos & Controle de Estoque</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Total de <strong className="text-white">{products.length}</strong> produtos cadastrados na loja virtual.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddProduct(true)}
              className="px-4 py-2.5 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-[#1fa64b]/20 transition-all active:scale-95 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Novo Produto</span>
            </button>
          </div>

          {/* Feedback Toast Notification */}
          {feedbackToast && (
            <div className={`p-3.5 rounded-2xl border text-xs font-semibold flex items-center justify-between gap-3 animate-in fade-in duration-200 ${
              feedbackToast.type === 'success'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
            }`}>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{feedbackToast.message}</span>
              </div>
              <button
                type="button"
                onClick={() => setFeedbackToast(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-0.5 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* Search bar for products in admin */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar produto por nome, categoria ou marca no catálogo..."
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              className="w-full bg-slate-900 border border-white/10 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-[#1fa64b]/60 transition-colors"
            />
            {productSearch && (
              <button
                type="button"
                onClick={() => setProductSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs px-1 cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3">Foto</th>
                  <th className="p-3">Nome do Produto</th>
                  <th className="p-3">Categoria</th>
                  <th className="p-3">Condição</th>
                  <th className="p-3">Custo</th>
                  <th className="p-3">Venda</th>
                  <th className="p-3">Lucro Unitário</th>
                  <th className="p-3">Estoque</th>
                  <th className="p-3 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {products
                  .filter((p) => {
                    if (!productSearch.trim()) return true;
                    const query = productSearch.toLowerCase();
                    return (
                      p.name.toLowerCase().includes(query) ||
                      p.category.toLowerCase().includes(query) ||
                      p.brand.toLowerCase().includes(query)
                    );
                  })
                  .map((p) => {
                    const unitProfit = p.price - p.costPrice;
                    return (
                      <tr key={p.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="p-3">
                          <img src={p.images[0]} alt={p.name} className="w-10 h-10 rounded-lg object-cover bg-slate-900 border border-white/10" />
                        </td>
                        <td className="p-3 font-semibold text-white max-w-xs">{p.name}</td>
                        <td className="p-3">{p.category}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            p.condition === 'novo' ? 'bg-[#1fa64b]/20 text-[#1fa64b]' : 'bg-[#f4c430]/20 text-[#f4c430]'
                          }`}>
                            {p.condition}
                          </span>
                        </td>
                        <td className="p-3 text-slate-400">R$ {p.costPrice.toFixed(2)}</td>
                        <td className="p-3 font-bold text-white">R$ {p.price.toFixed(2)}</td>
                        <td className="p-3 text-[#1fa64b] font-bold">R$ {unitProfit.toFixed(2)}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min="0"
                              value={p.stock}
                              onChange={(e) => onUpdateStock(p.id, parseInt(e.target.value) || 0)}
                              className="w-16 bg-slate-900 border border-white/20 rounded-lg p-1 text-center text-white"
                            />
                            {p.stock <= 3 && (
                              <span className="text-[10px] text-rose-400 font-bold">Baixo!</span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 text-center">
                          <button
                            type="button"
                            onClick={() => setProductToDelete(p)}
                            className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/35 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm"
                            title={`Excluir ${p.name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            <span>Excluir</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                {products.length === 0 && (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-400">
                      Nenhum produto cadastrado no catálogo. Clique em "Cadastrar Novo Produto" para adicionar.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Modal Add Product */}
          {showAddProduct && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#121826] p-6 rounded-3xl border border-[#1fa64b]/40 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-white text-base">Cadastrar Novo Produto</h4>
                  <button onClick={() => setShowAddProduct(false)} className="text-slate-400 hover:text-white">✕</button>
                </div>

                <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 mb-1">Nome do Produto *</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: iPhone 14 128GB Azul"
                      value={newProdName}
                      onChange={(e) => setNewProdName(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-300 mb-1">Categoria:</label>
                      <select
                        value={newProdCategory}
                        onChange={(e: any) => setNewProdCategory(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      >
                        <option value="Smartphones">Smartphones</option>
                        <option value="Tablets">Tablets</option>
                        <option value="Acessórios">Acessórios</option>
                        <option value="Baterias">Baterias</option>
                        <option value="Carregadores & Cabos">Carregadores & Cabos</option>
                        <option value="Caixas de Som">Caixas de Som</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-300 mb-1">Condição:</label>
                      <select
                        value={newProdCondition}
                        onChange={(e: any) => setNewProdCondition(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      >
                        <option value="seminovo">Seminovo Revisado (Garantia 90 Dias)</option>
                        <option value="novo">Acessório Original (Garantia 90 Dias)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-slate-300 mb-1">Preço Venda *</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        placeholder="R$ 0,00"
                        value={newProdPrice}
                        onChange={(e) => setNewProdPrice(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Preço Custo *</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        placeholder="R$ 0,00"
                        value={newProdCost}
                        onChange={(e) => setNewProdCost(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Estoque Inicial</label>
                      <input
                        type="number"
                        min="1"
                        value={newProdStock}
                        onChange={(e) => setNewProdStock(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1">URL da Imagem</label>
                    <input
                      type="text"
                      value={newProdImg}
                      onChange={(e) => setNewProdImg(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none text-[11px]"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddProduct(false)}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs font-bold"
                    >
                      Cadastrar Produto
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Modal de Confirmação de Exclusão de Produto (100% no DOM, sem dependência de window.confirm) */}
          {productToDelete && (
            <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#121826] p-6 rounded-3xl border border-rose-500/40 max-w-md w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                    <Trash2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-base">Excluir Produto do Catálogo</h4>
                    <p className="text-xs text-slate-400">Esta ação não poderá ser desfeita</p>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-900/90 rounded-2xl border border-white/10 flex items-center gap-3">
                  <img
                    src={productToDelete.images[0] || 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=800&q=80'}
                    alt={productToDelete.name}
                    className="w-14 h-14 rounded-xl object-cover bg-slate-800 shrink-0 border border-white/10"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-white text-sm truncate">{productToDelete.name}</p>
                    <p className="text-xs text-slate-400">
                      {productToDelete.category} • <span className="text-[#1fa64b] font-bold">R$ {productToDelete.price.toFixed(2)}</span>
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Estoque: <span className="text-white font-semibold">{productToDelete.stock} un</span> | Condição: <span className="text-[#f4c430] uppercase font-semibold">{productToDelete.condition}</span>
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Você tem certeza de que deseja remover permanentemente o produto <strong className="text-white">"{productToDelete.name}"</strong>? Ele será retirado imediatamente da vitrine de clientes e do controle de estoque.
                </p>

                <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setProductToDelete(null)}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const deletedName = productToDelete.name;
                      onDeleteProduct(productToDelete.id);
                      setProductToDelete(null);
                      setFeedbackToast({
                        message: `Produto "${deletedName}" foi excluído com sucesso do catálogo!`,
                        type: 'success'
                      });
                      setTimeout(() => setFeedbackToast(null), 5000);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-rose-900/40 transition-all cursor-pointer active:scale-95"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Sim, Excluir Produto</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: Garantias & IMEI */}
      {activeTab === 'garantias' && (
        <div className="bg-[#121826] rounded-3xl border border-white/10 p-5 sm:p-7 shadow-2xl space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-white">Registro e Controle de Garantias por IMEI</h3>
            <button
              onClick={() => setShowAddWarranty(true)}
              className="px-4 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
            >
              <Plus className="w-4 h-4" />
              <span>Registrar Nova Garantia</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3">Protocolo</th>
                  <th className="p-3">IMEI / Serial</th>
                  <th className="p-3">Aparelho</th>
                  <th className="p-3">Cliente</th>
                  <th className="p-3">Compra</th>
                  <th className="p-3">Vencimento</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {warranties.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-[#f4c430]">{w.protocol}</td>
                    <td className="p-3 font-mono text-white">{w.imeiOrSerial}</td>
                    <td className="p-3 font-medium text-white">{w.productName}</td>
                    <td className="p-3">{w.customerName} ({w.customerPhone})</td>
                    <td className="p-3">{new Date(w.purchaseDate).toLocaleDateString('pt-BR')}</td>
                    <td className="p-3 font-semibold text-[#f4c430]">
                      {new Date(w.expirationDate).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        w.status === 'ativa' ? 'bg-[#1fa64b]/20 text-[#1fa64b]' : 'bg-rose-500/20 text-rose-400'
                      }`}>
                        {w.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Modal Add Warranty */}
          {showAddWarranty && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#121826] p-6 rounded-3xl border border-[#1fa64b]/40 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-white text-base">Registrar Nova Garantia no Sistema</h4>
                  <button onClick={() => setShowAddWarranty(false)} className="text-slate-400 hover:text-white">✕</button>
                </div>

                <form onSubmit={handleSaveWarranty} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 mb-1">IMEI ou Número de Série (15 dígitos) *</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: 356892110482910"
                      value={warImei}
                      onChange={(e) => setWarImei(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1">Nome do Aparelho *</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: iPhone 13 128GB Meia-Noite"
                      value={warProduct}
                      onChange={(e) => setWarProduct(e.target.value)}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-300 mb-1">Nome do Cliente *</label>
                      <input
                        type="text"
                        required
                        placeholder="Nome completo"
                        value={warCustomer}
                        onChange={(e) => setWarCustomer(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">WhatsApp Cliente *</label>
                      <input
                        type="text"
                        required
                        placeholder="(67) 98135-9433"
                        value={warPhone}
                        onChange={(e) => setWarPhone(e.target.value)}
                        className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1">Prazo de Garantia:</label>
                    <select
                      value={warMonths}
                      onChange={(e) => setWarMonths(parseInt(e.target.value))}
                      className="w-full bg-slate-900 border border-white/20 rounded-xl p-2 text-white outline-none"
                    >
                      <option value={12}>12 Meses (Aparelhos Novos)</option>
                      <option value={6}>6 Meses (Seminovos Revisados)</option>
                      <option value={3}>3 Meses / 90 Dias (Serviço de Bancada)</option>
                    </select>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddWarranty(false)}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white text-xs font-bold"
                    >
                      Salvar Garantia
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: Configurações & PagBank */}
      {activeTab === 'config' && (
        <div className="bg-[#121826] rounded-3xl border border-white/10 p-6 sm:p-8 shadow-2xl max-w-3xl mx-auto space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#1fa64b]" />
            <span>Configurações da Loja & API Oficial PagBank</span>
          </h3>

          <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-3 text-xs">
            <h4 className="font-bold text-[#f4c430] uppercase text-[11px]">Integração PagBank Pix</h4>
            <div>
              <label className="block text-slate-300 mb-1">Ambiente PagBank Ativo:</label>
              <select className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-white outline-none">
                <option value="sandbox">Sandbox (Ambiente de Testes Seguro Homologado)</option>
                <option value="producao">Produção (Cobranças Reais)</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Token de Autenticação PagBank (Bearer):</label>
              <input
                type="password"
                value="••••••••••••••••••••••••••••••••"
                readOnly
                className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-slate-400 font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                * Conforme exigido, o token oficial é mantido no backend server-side com proteção contra exposição.
              </span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-3 text-xs">
            <h4 className="font-bold text-[#1fa64b] uppercase text-[11px]">Configurações da Loja Física Itaquiraí-MS</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-300 mb-1">Política de Envio:</label>
                <input
                  type="text"
                  readOnly
                  value="100% Retirada Presencial no Balcão (Sem entrega)"
                  className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-slate-300 outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">WhatsApp Notificações:</label>
                <input
                  type="text"
                  defaultValue="67981359433"
                  className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-white outline-none"
                />
              </div>
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Endereço Oficial da Loja Física:</label>
              <input
                type="text"
                defaultValue={STORE_INFO.address}
                className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Horário de Funcionamento Oficial:</label>
              <input
                type="text"
                readOnly
                value={STORE_INFO.hours}
                className="w-full bg-slate-950 border border-white/15 rounded-xl p-2 text-slate-300 outline-none"
              />
            </div>
          </div>

          {/* Card de Download dos Códigos & Termux */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-[#1fa64b]/40 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-[#1fa64b] uppercase text-[11px] flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-[#1fa64b]" />
                <span>Código-Fonte & Instalação no Termux (Android)</span>
              </h4>
              <span className="px-2 py-0.5 rounded-full bg-[#1fa64b]/20 text-[#1fa64b] text-[10px] font-bold">
                Pacote .ZIP Pronto
              </span>
            </div>

            <p className="text-slate-300 text-xs leading-relaxed">
              Você pode baixar todos os arquivos e pastas deste projeto para hospedar onde quiser ou rodar diretamente no seu smartphone via <strong>Termux</strong>.
            </p>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <a
                href="/api/download-zip"
                download="digital-cell-completo.zip"
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow cursor-pointer text-center"
              >
                <Download className="w-4 h-4" />
                <span>Baixar Pasta com os Códigos (.ZIP)</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  const termuxCmds = `pkg update && pkg upgrade -y\npkg install nodejs-lts git unzip -y\ntermux-setup-storage\nmkdir -p ~/digital-cell && cd ~/digital-cell\ncp /sdcard/Download/digital-cell-completo.zip .\nunzip -o digital-cell-completo.zip\nnpm install\nbash termux-start.sh`;
                  navigator.clipboard.writeText(termuxCmds);
                  setCopiedTermux(true);
                  setTimeout(() => setCopiedTermux(false), 3000);
                }}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-white/10 transition-colors cursor-pointer"
              >
                {copiedTermux ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-300" />}
                <span>{copiedTermux ? 'Comandos Copiados!' : 'Copiar Comandos Termux'}</span>
              </button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-white/10 font-mono text-[11px] text-slate-300 space-y-1">
              <p className="text-slate-400 font-bold mb-1">// Comandos rápidos no Termux:</p>
              <p className="text-[#1fa64b]">$ pkg install nodejs-lts unzip -y</p>
              <p className="text-[#1fa64b]">$ unzip digital-cell-completo.zip && npm install</p>
              <p className="text-[#f4c430]">$ bash termux-start.sh</p>
              <p className="text-slate-400 text-[10px] mt-1">Acesso no navegador do celular: http://localhost:3000</p>
            </div>
          </div>

          {settingsSaved && (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Configurações da loja física e PagBank salvas com sucesso!</span>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setSettingsSaved(true);
              setTimeout(() => setSettingsSaved(false), 4000);
            }}
            className="w-full py-3 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Salvar Configurações
          </button>
        </div>
      )}

    </div>
  );
};
