import React from 'react';
import { ShoppingCart, Star, Shield, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onViewProduct
}) => {
  const hasPromo = product.promotionalPrice && product.promotionalPrice < product.price;
  const currentPrice = hasPromo ? product.promotionalPrice! : product.price;
  const discountPercent = hasPromo 
    ? Math.round(((product.price - product.promotionalPrice!) / product.price) * 100) 
    : 0;

  return (
    <div className="card cursor-pointer group" onClick={() => onViewProduct(product)}>
      <div className="card2 p-3 sm:p-4 justify-between">
        
        {/* Top Badges & Product Image */}
        <div>
          <div className="relative w-full h-44 sm:h-48 rounded-xl overflow-hidden bg-slate-900/60 mb-3 flex items-center justify-center">
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
            
            {/* Condition Badge (Seminovo com 90 dias) */}
            <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
              {product.category === 'Smartphones' || product.condition === 'seminovo' ? (
                <span className="px-2 py-0.5 rounded-md bg-[#f4c430] text-[#0b2c5a] text-[10px] font-black uppercase tracking-wider shadow">
                  Seminovo • 90 Dias
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-md bg-[#1fa64b] text-white text-[10px] font-black uppercase tracking-wider shadow">
                  Garantia 90 Dias
                </span>
              )}

              {hasPromo && (
                <span className="px-2 py-0.5 rounded-md bg-[#e11d48] text-white text-[10px] font-black tracking-wider shadow">
                  -{discountPercent}% OFF
                </span>
              )}
            </div>

            {/* Quick View Button on Hover */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onViewProduct(product);
              }}
              className="absolute bottom-2 right-2 p-2 rounded-full bg-[#121826]/80 text-white hover:bg-[#1fa64b] transition-colors shadow-lg opacity-90 group-hover:opacity-100"
              title="Ver detalhes do produto"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-medium text-[#1fa64b] uppercase text-[11px] tracking-wide">
              {product.category}
            </span>
            <div className="flex items-center gap-1 text-[#f4c430]">
              <Star className="w-3 h-3 fill-[#f4c430]" />
              <span className="text-[11px] font-semibold text-slate-300">
                {product.rating.toFixed(1)}
              </span>
            </div>
          </div>

          {/* Product Name */}
          <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-[#38e370] transition-colors line-clamp-1 mb-1">
            {product.name}
          </h3>

          {/* Description */}
          <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-2">
            {product.description}
          </p>

          {/* Warranty badge */}
          <div className="inline-flex items-center gap-1 text-[11px] text-slate-400 mb-2">
            <Shield className="w-3 h-3 text-[#1fa64b]" />
            <span>Garantia de {product.warrantyMonths === 3 ? '90 dias' : `${product.warrantyMonths * 30} dias (90 dias)`}</span>
          </div>
        </div>

        {/* Price & Action Button */}
        <div className="pt-2 border-t border-white/10 mt-auto">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-lg sm:text-xl font-extrabold text-white">
              R$ {currentPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            {hasPromo && (
              <span className="text-xs text-slate-400 line-through">
                R$ {product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            )}
          </div>

          <div className="text-[11px] text-[#1fa64b] font-medium mb-3">
            ou 12x de R$ {(currentPrice / 10).toFixed(2).replace('.', ',')} no cartão
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
            disabled={product.stock <= 0}
            className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
              product.stock > 0
                ? 'bg-[#1fa64b] hover:bg-[#25be5a] text-white shadow-md shadow-[#1fa64b]/20 active:scale-95'
                : 'bg-slate-700 text-slate-400 cursor-not-allowed'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>{product.stock > 0 ? 'Adicionar ao Carrinho' : 'Esgotado'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
