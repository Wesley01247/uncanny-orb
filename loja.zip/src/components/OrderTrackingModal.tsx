import React, { useState } from 'react';
import { 
  Package, 
  Search, 
  Truck, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  ExternalLink, 
  AlertCircle,
  Store
} from 'lucide-react';
import { Order, DeliveryStatus } from '../types';
import { STORE_INFO } from '../data/mockData';

interface OrderTrackingModalProps {
  orders: Order[];
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({ orders }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0] || null);
  const [searchError, setSearchError] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    const term = searchTerm.trim().toUpperCase();

    if (!term) return;

    const match = orders.find(
      o => o.id.toUpperCase() === term || 
           o.customerPhone.replace(/\D/g, '').includes(term.replace(/\D/g, ''))
    );

    if (match) {
      setSelectedOrder(match);
    } else {
      setSearchError('Pedido não encontrado. Verifique o código (ex: PED-123456) ou seu WhatsApp.');
    }
  };

  const getStepActive = (status: DeliveryStatus, stepIndex: number) => {
    let current = 0;
    switch (status) {
      case 'aguardando_pagamento': current = 0; break;
      case 'pago': current = 1; break;
      case 'em_separacao':
      case 'em_preparacao': current = 2; break;
      case 'pronto_retirada':
      case 'saiu_para_entrega': current = 3; break;
      case 'retirado':
      case 'entregue': current = 4; break;
      default: current = 0;
    }
    return current >= stepIndex;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Banner */}
      <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1fa64b]/20 border border-[#1fa64b]/40 text-[#1fa64b] text-xs font-bold uppercase">
          <Store className="w-4 h-4 text-[#38bdf8]" />
          <span>Acompanhamento de Retirada</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          Acompanhe Seu Pedido para Retirada
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Acompanhe a confirmação do Pix PagBank, separação na loja e disponibilidade para retirada em Itaquiraí-MS.
        </p>
      </div>

      {/* Search Input */}
      <div className="bg-[#121826] p-5 sm:p-7 rounded-3xl border border-white/10 shadow-xl mb-6">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            placeholder="Digite o código do pedido (ex: PED-123456) ou seu telefone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-slate-900 border border-white/15 rounded-xl px-4 py-3 text-white text-xs sm:text-sm outline-none focus:border-[#1fa64b]"
          />
          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-[#1fa64b] hover:bg-[#25be5a] text-white font-bold text-xs sm:text-sm transition-all cursor-pointer"
          >
            Rastrear Pedido
          </button>
        </form>
        {searchError && <p className="text-xs text-rose-400 mt-2">{searchError}</p>}
      </div>

      {/* Selected Order Display */}
      {selectedOrder ? (
        <div className="bg-[#121826] rounded-3xl border border-[#1fa64b]/30 p-6 sm:p-8 shadow-2xl space-y-6">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-mono font-black text-[#f4c430]">
                  #{selectedOrder.id}
                </span>
                <span className="text-xs text-slate-400">
                  {new Date(selectedOrder.createdAt).toLocaleDateString('pt-BR')} às {new Date(selectedOrder.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Cliente: <strong>{selectedOrder.customerName}</strong> ({selectedOrder.customerPhone})
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-xs text-slate-400 block">Total do Pedido:</span>
              <span className="text-xl font-black text-white">
                R$ {selectedOrder.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Timeline */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-4">
              Progresso do Pedido na Loja
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className={`p-3 rounded-2xl border transition-all ${
                getStepActive(selectedOrder.deliveryStatus, 1)
                  ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-[#1fa64b] font-bold'
                  : 'bg-slate-900 border-white/10 text-slate-500'
              }`}>
                <CheckCircle2 className="w-5 h-5 mx-auto mb-1" />
                <span>1. Pagamento Confirmado</span>
              </div>

              <div className={`p-3 rounded-2xl border transition-all ${
                getStepActive(selectedOrder.deliveryStatus, 2)
                  ? 'bg-[#1fa64b]/20 border-[#1fa64b] text-[#1fa64b] font-bold'
                  : 'bg-slate-900 border-white/10 text-slate-500'
              }`}>
                <Package className="w-5 h-5 mx-auto mb-1" />
                <span>2. Em Separação</span>
              </div>

              <div className={`p-3 rounded-2xl border transition-all ${
                getStepActive(selectedOrder.deliveryStatus, 3)
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8] text-[#38bdf8] font-bold'
                  : 'bg-slate-900 border-white/10 text-slate-500'
              }`}>
                <Store className="w-5 h-5 mx-auto mb-1" />
                <span>3. Pronto p/ Retirada</span>
              </div>

              <div className={`p-3 rounded-2xl border transition-all ${
                getStepActive(selectedOrder.deliveryStatus, 4)
                  ? 'bg-[#f4c430]/20 border-[#f4c430] text-[#f4c430] font-black'
                  : 'bg-slate-900 border-white/10 text-slate-500'
              }`}>
                <CheckCircle2 className="w-5 h-5 mx-auto mb-1" />
                <span>4. Retirado pelo Cliente</span>
              </div>
            </div>
          </div>

          {/* Pickup & Items details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-2">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Store className="w-4 h-4 text-[#1fa64b]" />
                <span>Local de Retirada do Pedido:</span>
              </span>
              <div className="text-slate-300 space-y-0.5">
                <p className="font-semibold text-white">Digital Cell Celulares (Loja Física):</p>
                <p>{STORE_INFO.address}</p>
                <p className="text-slate-400">Horário: {STORE_INFO.hours}</p>
                <p className="text-[#1fa64b] font-medium pt-1">Retirada gratuita com apresentação do código #{selectedOrder.id}.</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-2">
              <span className="font-bold text-slate-300 block">Itens do Pedido:</span>
              <div className="space-y-1.5">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center text-slate-300">
                    <span className="truncate max-w-[200px]">
                      {item.quantity}x {item.name}
                    </span>
                    <span className="font-bold text-white shrink-0">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Action */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <span className="text-slate-400">
              Precisa de ajuda ou alteração no seu pedido?
            </span>
            <a
              href={`https://wa.me/${STORE_INFO.phone}?text=Olá!%20Gostaria%20de%20informações%20sobre%20meu%20pedido%20%23${selectedOrder.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd59] text-white font-bold flex items-center gap-1.5 shadow"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Chamar Suporte no WhatsApp (67) 98135-9433</span>
            </a>
          </div>

        </div>
      ) : (
        <div className="p-8 text-center bg-[#121826] rounded-3xl border border-white/10 text-slate-400">
          <p>Nenhum pedido selecionado. Digite o código do seu pedido acima.</p>
        </div>
      )}
    </div>
  );
};
