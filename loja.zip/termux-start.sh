#!/data/data/com.termux/files/usr/bin/bash

echo "================================================="
echo "   DIGITAL CELL CELULARES - INICIALIZADOR TERMUX  "
echo "        Rua Campo Grande, 1161 - Itaquiraí-MS     "
echo "================================================="

# 1. Verificar se o Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "[!] Node.js não encontrado. Instalando dependências do sistema..."
    pkg update -y
    pkg install nodejs-lts git -y
else
    echo "[✓] Node.js detectado: $(node -v)"
fi

# 2. Verificar pasta node_modules
if [ ! -d "node_modules" ]; then
    echo "[*] Instalando pacotes do projeto (npm install)..."
    npm install
else
    echo "[✓] Dependências já instaladas."
fi

# 3. Iniciar o servidor
echo ""
echo "================================================="
echo "  Iniciando servidor Digital Cell na porta 3000  "
echo "  Acesse no navegador do celular:                 "
echo "  ==> http://localhost:3000                      "
echo "================================================="
echo ""

npm run dev
