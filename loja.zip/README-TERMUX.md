# Guia de Instalação e Execução no Termux (Android)
**Digital Cell Celulares — Itaquiraí-MS**

Este guia ensina passo a passo como rodar a loja virtual e o sistema administrativo da Digital Cell diretamente no seu celular Android utilizando o aplicativo **Termux**.

---

## 1. Instalar o Termux
Recomendamos baixar o Termux atualizado pelo **F-Droid** ou pelo GitHub oficial do Termux (evite a versão da Google Play Store pois está desatualizada).

---

## 2. Passo a Passo Rápido (Comandos no Termux)

Abra o aplicativo **Termux** e digite os comandos abaixo:

### Passo 1: Atualizar pacotes do sistema
```bash
pkg update && pkg upgrade -y
```

### Passo 2: Instalar o Node.js e Git
```bash
pkg install nodejs-lts git wget unzip -y
```

### Passo 3: Baixar ou Extrair a Pasta com os Códigos
Se você baixou o arquivo `digital-cell-completo.zip` para a memória do seu celular (pasta Download):
```bash
# Dar permissão de armazenamento ao Termux
termux-setup-storage

# Criar a pasta do projeto e extrair o arquivo
mkdir -p ~/digital-cell
cp /sdcard/Download/digital-cell-completo.zip ~/digital-cell/
cd ~/digital-cell
unzip -o digital-cell-completo.zip
```

### Passo 4: Instalar as Dependências do Projeto
```bash
npm install
```

### Passo 5: Iniciar o Sistema
Você pode rodar diretamente com o script automático:
```bash
bash termux-start.sh
```
Ou pelo comando padrão do npm:
```bash
npm run dev
```

---

## 3. Como Acessar a Loja no Celular
Assim que o terminal exibir:
```
Digital Cell Server rodando na porta 3000
```
Abra o navegador do seu celular (Google Chrome, Samsung Internet, Firefox, etc.) e acesse:
👉 **`http://localhost:3000`**

---

## 4. Como Acessar o Painel Administrativo no Termux
1. No menu superior ou rodapé da loja, clique em **"Painel ADM"** (ou acesse a aba administrativa).
2. Digite suas credenciais:
   - **E-mail:** `admin@digitalcell.com.br` (ou `admin`)
   - **Senha:** `admin123` (ou `123456`)
3. No painel você gerencia:
   - Produtos e controle de estoque
   - Adicionar e excluir produtos com 1 clique
   - Acompanhamento de Ordens de Serviço (Assistência Técnica)
   - Registro de Garantias de 90 dias por IMEI
   - Relatórios financeiros e vendas
   - Configurações da API oficial PagBank Pix

---

## 5. Dica para Manter Rodando em Segundo Plano
Para evitar que o Android feche o Termux para economizar bateria:
1. Puxe a barra de notificações do celular.
2. Na notificação do Termux, clique em **"Acquire Wakelock"**.
3. O servidor continuará rodando mesmo com a tela desligada.
