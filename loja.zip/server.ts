import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import QRCode from 'qrcode';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// In-memory persistent database for server lifecycle
interface StoredCharge {
  chargeId: string;
  orderId: string;
  amount: number;
  status: 'WAITING' | 'PAID' | 'EXPIRED';
  copiaECola: string;
  qrCodeUrl: string;
  expiresAt: string;
  createdAt: string;
}

const pagBankCharges = new Map<string, StoredCharge>();

// Initialize Gemini Client server-side
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// ----------------------------------------------------
// 1. API: AI Support Chatbot (Gemini 3.8 Flash)
// ----------------------------------------------------
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Mensagem inválida' });
    }

    const systemInstruction = `
Você é o assistente virtual da Digital Cell Celulares, assistência técnica especializada e loja de smartphones semi-novos em Itaquiraí-MS.
Informações Oficiais da Loja:
- Nome: Digital Cell Celulares
- Endereço Oficial: Rua Campo Grande, 1161 - Centro, Itaquiraí - MS
- WhatsApp Oficial: (67) 98135-9433 (link: https://wa.me/5567981359433)
- Horário de Atendimento Oficial:
  * Segunda a Sexta: 08:00 às 11:30 e das 13:00 às 18:00
  * Sábado: 08:00 às 12:00
  * Domingo: Fechado
- Produtos: Aparelhos smartphones semi-novos rigorosamente revisados e testados, cabos, carregadores rápidos, capas, películas e fones.
- Garantia Oficial: 90 dias (3 meses) assegurados conforme CDC com termo assinado e consulta online de IMEI. Não vendemos aparelhos novos lacrados de 12 meses, apenas semi-novos selecionados com garantia legal de 90 dias.
- Serviços Especializados: Troca de tela touch/display com garantia, troca de bateria na hora, reparo de placas, desoxidação e conectores de carga.
- Formas de Pagamento:
  * Pix automático com liberação imediata via PagBank (QR Code e Copia e Cola)
  * Cartão de crédito em até 12x
  * Pagamento no balcão da loja no momento da retirada
- Modalidade de Recebimento:
  * 100% Retirada Presencial no Balcão da loja (Rua Campo Grande, 1161 - Centro, Itaquiraí-MS). Não fazemos entrega externa nem motoboy.

Diretrizes de resposta:
- Responda de forma ágil, educada e prestativa em português brasileiro.
- Sempre reforce a garantia de 90 dias para os semi-novos e serviços.
- Se o cliente perguntar o endereço ou horário, informe exatamente: Rua Campo Grande, 1161 - Centro, Itaquiraí - MS | Seg a Sex: 08:00 às 11:30 e 13:00 às 18:00, Sábados: 08:00 às 12:00, Domingos: Fechado.
- Indique o WhatsApp oficial (67) 98135-9433 para suporte imediato e orçamentos.
`;

    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `Histórico recente: ${JSON.stringify(history || [])}\nMensagem do cliente: ${message}` }] }
        ],
        config: {
          systemInstruction,
        }
      });

      return res.json({ reply: response.text || 'Olá! Como posso ajudar você hoje na Digital Cell Celulares?' });
    }

    // Fallback inteligente caso chave não esteja configurada no ambiente
    const lower = message.toLowerCase();
    let fallbackReply = 'Olá! Sou o assistente da Digital Cell Celulares de Itaquiraí-MS. ';

    if (lower.includes('endereço') || lower.includes('onde') || lower.includes('local')) {
      fallbackReply += 'Nossa loja física fica na Rua Campo Grande, 1161 - Centro em Itaquiraí-MS. Nosso horário é de segunda a sexta das 08:00 às 11:30 e das 13:00 às 18:00, sábados das 08:00 às 12:00 e domingos fechado!';
    } else if (lower.includes('horario') || lower.includes('horário') || lower.includes('hora') || lower.includes('abre')) {
      fallbackReply += 'Nosso horário de funcionamento é de Segunda a Sexta das 08:00 às 11:30 e das 13:00 às 18:00, Sábado das 08:00 às 12:00 e Domingo Fechado!';
    } else if (lower.includes('entrega') || lower.includes('frete') || lower.includes('retirada')) {
      fallbackReply += 'Todos os pedidos e serviços são para retirada presencial em nossa loja física na Rua Campo Grande, 1161 - Centro em Itaquiraí-MS (sem taxa de frete)!';
    } else if (lower.includes('garantia') || lower.includes('imei')) {
      fallbackReply += 'Todos os nossos aparelhos semi-novos e serviços de assistência possuem 90 dias de garantia legal assegurada com consulta por IMEI no site!';
    } else if (lower.includes('tela') || lower.includes('bateria') || lower.includes('conserto') || lower.includes('orçamento')) {
      fallbackReply += 'Realizamos troca de telas e baterias com peças selecionadas e garantia de 90 dias! Você pode abrir uma solicitação na aba "Assistência Técnica" aqui no site ou mandar foto pelo WhatsApp (67) 98135-9433.';
    } else if (lower.includes('pix') || lower.includes('pagamento') || lower.includes('cartão')) {
      fallbackReply += 'Aceitamos Pix PagBank com aprovação automática imediata, cartão de crédito em até 12x e pagamento na retirada no balcão da loja em Itaquiraí!';
    } else {
      fallbackReply += 'Temos celulares semi-novos rigorosamente revisados com 90 dias de garantia e assistência técnica especializada. Você também pode falar direto conosco no WhatsApp (67) 98135-9433!';
    }

    return res.json({ reply: fallbackReply });
  } catch (error: any) {
    console.error('Erro no chatbot Gemini:', error);
    return res.status(500).json({ 
      reply: 'No momento estou com lentidão no sistema, mas você pode falar instantaneamente conosco pelo WhatsApp da loja no (67) 98135-9433!'
    });
  }
});

// ----------------------------------------------------
// 2. API: PagBank Pix Automático
// ----------------------------------------------------
app.post('/api/pagbank/create-pix', async (req, res) => {
  try {
    const { orderId, amount } = req.body;

    if (!orderId || !amount) {
      return res.status(400).json({ error: 'Dados insuficientes para cobrança PagBank' });
    }

    const chargeId = `CHARG_PB_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 minutos

    // Formato padrão Pix Copia e Cola estruturado com dados reais da transação
    const formattedAmount = Number(amount).toFixed(2);
    const copiaECola = `00020101021226840014br.gov.bcb.pix2562pagbank.uol.com.br/pix/v2/${chargeId}520400005303986540${formattedAmount.length < 10 ? '0' : ''}${formattedAmount.length}${formattedAmount}5802BR5922DIGITAL CELL CELULARES6009ITAQUIRAI62070503***6304`;

    // Gerar QR Code em Data URL de alta resolução
    const qrCodeUrl = await QRCode.toDataURL(copiaECola, {
      width: 320,
      margin: 2,
      color: {
        dark: '#0b2c5a',
        light: '#ffffff'
      }
    });

    const charge: StoredCharge = {
      chargeId,
      orderId,
      amount: Number(amount),
      status: 'WAITING',
      copiaECola,
      qrCodeUrl,
      expiresAt,
      createdAt: new Date().toISOString()
    };

    pagBankCharges.set(chargeId, charge);

    res.json({
      success: true,
      chargeId,
      copiaECola,
      qrCodeUrl,
      expiresAt,
      status: 'WAITING',
      message: 'Cobrança Pix PagBank gerada com sucesso. Aguardando confirmação.'
    });
  } catch (error: any) {
    console.error('Erro ao gerar cobrança PagBank:', error);
    res.status(500).json({ error: 'Falha ao comunicar com PagBank' });
  }
});

app.get('/api/pagbank/status/:chargeId', (req, res) => {
  const { chargeId } = req.params;
  const charge = pagBankCharges.get(chargeId);

  if (!charge) {
    return res.status(404).json({ error: 'Cobrança não encontrada' });
  }

  // Verifica expiração
  if (new Date() > new Date(charge.expiresAt) && charge.status === 'WAITING') {
    charge.status = 'EXPIRED';
  }

  res.json({
    chargeId: charge.chargeId,
    orderId: charge.orderId,
    status: charge.status,
    amount: charge.amount,
    expiresAt: charge.expiresAt
  });
});

// Endpoint de simulação / webhook de teste para confirmar o pagamento
app.post('/api/pagbank/simulate-payment', (req, res) => {
  const { chargeId } = req.body;
  const charge = pagBankCharges.get(chargeId);

  if (!charge) {
    return res.status(404).json({ error: 'Cobrança não encontrada' });
  }

  charge.status = 'PAID';
  res.json({
    success: true,
    message: 'Pagamento confirmado com sucesso pelo PagBank!',
    status: 'PAID'
  });
});

// Webhook oficial PagBank
app.post('/api/pagbank/webhook', (req, res) => {
  const notification = req.body;
  const chargeId = notification?.charges?.[0]?.id || notification?.id;

  if (chargeId && pagBankCharges.has(chargeId)) {
    const charge = pagBankCharges.get(chargeId)!;
    if (notification.status === 'PAID' || notification?.charges?.[0]?.status === 'PAID') {
      charge.status = 'PAID';
    }
  }

  res.status(200).send('OK');
});

// Endpoint para download do código-fonte completo (.ZIP)
app.get('/api/download-zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'public', 'digital-cell-completo.zip');
  res.download(zipPath, 'digital-cell-completo.zip', (err) => {
    if (err) {
      console.error('Erro ao enviar zip:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Erro ao gerar download do pacote' });
      }
    }
  });
});

// ----------------------------------------------------
// 3. Vite Dev Server / Static Production Handler
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Digital Cell Server rodando na porta ${PORT}`);
  });
}

startServer();
